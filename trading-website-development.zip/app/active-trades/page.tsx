"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { fetchSingleCryptoPrice } from "@/lib/crypto-api"

export default function ActiveTradesPage() {
  const router = useRouter()
  const [trades, setTrades] = useState<any[]>([])
  const [user, setUser] = useState<any>(null)
  const [currentPrices, setCurrentPrices] = useState<Record<string, number>>({})
  const [finishedTrades, setFinishedTrades] = useState<any[]>([])
  const [profitEnabled, setProfitEnabled] = useState(true)

  useEffect(() => {
    const currentUser = localStorage.getItem("currentUser")
    if (!currentUser) {
      router.push("/login")
      return
    }
    setUser(JSON.parse(currentUser))

    const adminSettings = JSON.parse(localStorage.getItem("adminSettings") || '{"profitableTradesEnabled": true}')
    setProfitEnabled(adminSettings.profitableTradesEnabled)

    loadTrades()
    const interval = setInterval(checkCompletedTrades, 1000)
    return () => clearInterval(interval)
  }, [router])

  useEffect(() => {
    const loadPrices = async () => {
      const symbols = [...new Set(trades.map((t) => t.symbol))]
      for (const symbol of symbols) {
        try {
          const priceData = await fetchSingleCryptoPrice(symbol)
          if (priceData && priceData.price) {
            setCurrentPrices((prev) => ({ ...prev, [symbol]: priceData.price }))
          }
        } catch (error) {
          console.log(`[v0] Failed to fetch price for ${symbol}`, error)
        }
      }
    }

    if (trades.length > 0) {
      loadPrices()
      const interval = setInterval(loadPrices, 5000)
      return () => clearInterval(interval)
    }
  }, [trades])

  const loadTrades = () => {
    const tradesData = localStorage.getItem("activeTrades") || "[]"
    setTrades(JSON.parse(tradesData))
  }

  const getRemainingTime = (startTime: number, duration: number) => {
    const elapsed = Date.now() - startTime
    const remaining = Math.max(0, duration * 1000 - elapsed)
    return Math.ceil(remaining / 1000)
  }

  const calculateLiveProfit = (trade: any, remainingSeconds: number) => {
    const totalDuration = trade.timeframe
    const elapsedPercent = ((totalDuration - remainingSeconds) / totalDuration) * 100

    const profitRanges: Record<number, { min: number; max: number }> = {
      60: { min: 5, max: 10 },
      90: { min: 12, max: 15 },
      120: { min: 15, max: 20 },
      180: { min: 20, max: 25 },
      360: { min: 25, max: 30 },
    }

    const range = profitRanges[trade.timeframe]

    if (!profitEnabled) {
      const targetLossPercent = -(range.min + Math.random() * (range.max - range.min))
      const currentLossPercent = (elapsedPercent / 100) * targetLossPercent
      const currentLoss = trade.amount * (currentLossPercent / 100)

      return {
        profitPercent: currentLossPercent,
        profit: currentLoss,
        targetProfitPercent: targetLossPercent,
      }
    }

    const currentPrice = currentPrices[trade.symbol] || trade.entryPrice
    const priceMovement = currentPrice - trade.entryPrice
    const priceChangePercent = (priceMovement / trade.entryPrice) * 100

    let targetProfitPercent: number

    if (trade.type === "long") {
      if (priceChangePercent > 0) {
        targetProfitPercent = range.min + (range.max - range.min) * 0.8
      } else {
        targetProfitPercent = range.min + (range.max - range.min) * 0.4
      }
    } else {
      if (priceChangePercent < 0) {
        targetProfitPercent = range.min + (range.max - range.min) * 0.8
      } else {
        targetProfitPercent = range.min + (range.max - range.min) * 0.4
      }
    }

    const currentProfitPercent = (elapsedPercent / 100) * targetProfitPercent
    const currentProfit = trade.amount * (currentProfitPercent / 100)

    return {
      profitPercent: currentProfitPercent,
      profit: currentProfit,
      targetProfitPercent,
    }
  }

  const calculateProfit = (trade: any) => {
    const currentPrice = currentPrices[trade.symbol] || trade.entryPrice
    const priceChangePercent = ((currentPrice - trade.entryPrice) / trade.entryPrice) * 100

    const profitRanges: Record<number, { min: number; max: number }> = {
      60: { min: 5, max: 10 },
      90: { min: 12, max: 15 },
      120: { min: 15, max: 20 },
      180: { min: 20, max: 25 },
      360: { min: 25, max: 30 },
    }

    const range = profitRanges[trade.timeframe]

    let profitPercent: number
    if (trade.type === "long") {
      if (priceChangePercent > 0) {
        profitPercent = range.min + (range.max - range.min) * 0.8
      } else {
        profitPercent = range.min + (range.max - range.min) * 0.4
      }
    } else {
      if (priceChangePercent < 0) {
        profitPercent = range.min + (range.max - range.min) * 0.8
      } else {
        profitPercent = range.min + (range.max - range.min) * 0.4
      }
    }

    return profitPercent
  }

  const checkCompletedTrades = () => {
    const tradesData = localStorage.getItem("activeTrades") || "[]"
    const activeTrades = JSON.parse(tradesData)
    const currentUser = localStorage.getItem("currentUser")

    if (!currentUser) return

    const user = JSON.parse(currentUser)
    const updatedUser = { ...user }
    const completedTradeIds: number[] = []
    const newFinishedTrades: any[] = []

    activeTrades.forEach((trade: any) => {
      const elapsed = Date.now() - trade.startTime
      if (elapsed >= trade.timeframe * 1000) {
        const adminSettings = JSON.parse(localStorage.getItem("adminSettings") || '{"profitableTradesEnabled": true}')
        const usersList = JSON.parse(localStorage.getItem("users") || "[]")
        const currentUserData = usersList.find((u: any) => u.email === user.email)

        let profitPercent: number

        if (adminSettings.profitableTradesEnabled && currentUserData?.allowed !== false) {
          profitPercent = calculateProfit(trade)
        } else {
          const profitRanges: Record<number, { min: number; max: number }> = {
            60: { min: 5, max: 10 },
            90: { min: 12, max: 15 },
            120: { min: 15, max: 20 },
            180: { min: 20, max: 25 },
            360: { min: 25, max: 30 },
          }
          const range = profitRanges[trade.timeframe]
          const lossPercent = range.min + Math.random() * (range.max - range.min)
          profitPercent = -lossPercent // Negative for loss
        }

        const profit = trade.amount * (profitPercent / 100)
        const totalReturn = trade.amount + profit

        const currentPrice = currentPrices[trade.symbol] || trade.entryPrice

        let exitPrice: number
        if (profitPercent > 0) {
          const profitAmount = 10 + Math.random() * 10
          exitPrice = currentPrice + profitAmount
        } else {
          const lossAmount = 10 + Math.random() * 10
          exitPrice = currentPrice - lossAmount
        }

        updatedUser.balance += totalReturn

        const completedTrade = {
          ...trade,
          completedTime: Date.now(),
          profitPercent: profitPercent.toFixed(2),
          profit: profit.toFixed(2),
          totalReturn: totalReturn.toFixed(2),
          exitPrice: exitPrice,
          status: "completed",
        }

        const historyData = localStorage.getItem("tradeHistory") || "[]"
        const history = JSON.parse(historyData)
        history.push(completedTrade)
        localStorage.setItem("tradeHistory", JSON.stringify(history))

        completedTradeIds.push(trade.id)
        newFinishedTrades.push(completedTrade)
      }
    })

    if (completedTradeIds.length > 0) {
      const remainingTrades = activeTrades.filter((t: any) => !completedTradeIds.includes(t.id))
      localStorage.setItem("activeTrades", JSON.stringify(remainingTrades))

      localStorage.setItem("currentUser", JSON.stringify(updatedUser))

      const usersData = localStorage.getItem("users") || "[]"
      const users = JSON.parse(usersData)
      const userIndex = users.findIndex((u: any) => u.email === updatedUser.email)
      if (userIndex !== -1) {
        users[userIndex] = updatedUser
        localStorage.setItem("users", JSON.stringify(users))
      }

      setFinishedTrades(newFinishedTrades)
      loadTrades()
    }
  }

  if (!user) return null

  if (finishedTrades.length > 0 && trades.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-8">
        <Card className="bg-slate-900/80 backdrop-blur border-slate-700 p-12 max-w-2xl w-full text-center">
          <div className="mb-6">
            <div className="w-20 h-20 bg-emerald-600/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-10 h-10 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <h2 className="text-3xl font-bold text-white mb-2">Trades Finished!</h2>
            <p className="text-slate-400">All your trades have been completed</p>
          </div>

          <div className="space-y-3 mb-8">
            {finishedTrades.map((trade, index) => (
              <div key={index} className="bg-slate-800/50 p-4 rounded-lg">
                <div className="flex items-center justify-between">
                  <span className="text-white font-semibold">{trade.name || trade.symbol}</span>
                  <span
                    className={`font-bold ${Number.parseFloat(trade.profitPercent) >= 0 ? "text-emerald-500" : "text-red-500"}`}
                  >
                    {Number.parseFloat(trade.profitPercent) >= 0 ? "+" : ""}
                    {trade.profitPercent}%
                  </span>
                </div>
                <div className="text-sm text-slate-400 mt-1">
                  ${Number.parseFloat(trade.amount).toLocaleString()} → $
                  {Number.parseFloat(trade.totalReturn).toLocaleString()}
                </div>
              </div>
            ))}
          </div>

          <Button
            onClick={() => router.push("/profile")}
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-lg py-6"
          >
            View Trade History
          </Button>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <header className="bg-slate-900/80 backdrop-blur-sm border-b border-slate-700 p-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              onClick={() => router.push("/dashboard")}
              variant="ghost"
              className="text-slate-400 hover:text-white"
            >
              ← Dashboard
            </Button>
            <h1 className="text-2xl font-bold text-white">Active Trades</h1>
          </div>
          <div className="text-right">
            <p className="text-sm text-slate-400">Balance</p>
            <p className="font-bold text-amber-500">${user?.balance?.toLocaleString()}</p>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto p-8">
        {trades.length === 0 ? (
          <Card className="bg-slate-900/80 backdrop-blur border-slate-700 p-12 text-center">
            <p className="text-slate-400 text-lg">No active trades</p>
            <Button onClick={() => router.push("/trade-list")} className="mt-4 bg-amber-600 hover:bg-amber-700">
              Start Trading
            </Button>
          </Card>
        ) : (
          <div className="grid gap-4">
            {trades.map((trade) => {
              const remainingSeconds = getRemainingTime(trade.startTime, trade.timeframe)
              const liveProfit = calculateLiveProfit(trade, remainingSeconds)
              const isFinished = remainingSeconds === 0
              const isLosing = liveProfit.profit < 0

              return (
                <Card key={trade.id} className="bg-slate-900/80 backdrop-blur border-slate-700 p-6">
                  <div className="flex items-center justify-between gap-6">
                    <div>
                      <h3 className="text-xl font-bold text-white">{trade.name || trade.symbol}</h3>
                      <p
                        className={`text-sm font-semibold ${trade.type === "long" ? "text-emerald-500" : "text-red-500"}`}
                      >
                        {trade.type === "long" ? "Buy Long ↑" : "Sell Short ↓"}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-slate-400">Trade Amount</p>
                      <p className="text-xl font-bold text-white">${trade.amount.toLocaleString()}</p>
                      <p className="text-xs text-slate-500">{trade.timeframeLabel}</p>
                    </div>
                    <div
                      className={`text-center ${isLosing ? "bg-red-950/30 border-red-500/30" : "bg-emerald-950/30 border-emerald-500/30"} border rounded-lg p-4 min-w-[180px]`}
                    >
                      <p className="text-xs text-slate-400 mb-1">{isLosing ? "Current Loss" : "Current Profit"}</p>
                      <p className={`text-2xl font-bold ${isLosing ? "text-red-500" : "text-emerald-500"}`}>
                        {isLosing ? "-" : "+"}${Math.abs(liveProfit.profit).toFixed(2)}
                      </p>
                      <p className={`text-sm ${isLosing ? "text-red-400" : "text-emerald-400"}`}>
                        {isLosing ? "" : "+"}
                        {liveProfit.profitPercent.toFixed(2)}%
                      </p>
                      <p className="text-xs text-slate-500 mt-1">
                        Target: {isLosing ? "-" : "~"}
                        {Math.abs(liveProfit.targetProfitPercent).toFixed(1)}%
                      </p>
                    </div>
                    <div className="text-center">
                      {isFinished ? (
                        <div className="bg-amber-950/30 border border-amber-500/30 rounded-lg px-6 py-3">
                          <p className="text-2xl font-bold text-amber-500">Finished</p>
                          <p className="text-xs text-slate-400">Settling...</p>
                        </div>
                      ) : (
                        <>
                          <p className="text-3xl font-bold text-amber-500">{remainingSeconds}s</p>
                          <p className="text-sm text-slate-400">remaining</p>
                        </>
                      )}
                    </div>
                  </div>
                </Card>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}
