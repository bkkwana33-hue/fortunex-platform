"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"

export default function AdminPage() {
  const router = useRouter()
  const [users, setUsers] = useState<any[]>([])
  const [adminSettings, setAdminSettings] = useState({ profitableTradesEnabled: true })
  const [selectedUser, setSelectedUser] = useState<any>(null)
  const [addFundAmount, setAddFundAmount] = useState("")
  const [adminPassword, setAdminPassword] = useState("")
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [customerMessages, setCustomerMessages] = useState<any[]>([])
  const [replyMessage, setReplyMessage] = useState("")
  const [selectedMessage, setSelectedMessage] = useState<any>(null)

  const ADMIN_PASSWORD = "admin123"

  useEffect(() => {
    loadUsers()
    loadAdminSettings()
    loadCustomerMessages()
  }, [])

  const loadUsers = () => {
    const usersData = localStorage.getItem("users") || "[]"
    setUsers(JSON.parse(usersData))
  }

  const loadAdminSettings = () => {
    const settings = localStorage.getItem("adminSettings") || '{"profitableTradesEnabled": true}'
    setAdminSettings(JSON.parse(settings))
  }

  const loadCustomerMessages = () => {
    const messages = localStorage.getItem("customerMessages") || "[]"
    setCustomerMessages(JSON.parse(messages))
  }

  const handleAdminLogin = () => {
    if (adminPassword === ADMIN_PASSWORD) {
      setIsAuthenticated(true)
    } else {
      alert("Incorrect admin password")
    }
  }

  const toggleProfitableTrades = () => {
    const newSettings = { ...adminSettings, profitableTradesEnabled: !adminSettings.profitableTradesEnabled }
    setAdminSettings(newSettings)
    localStorage.setItem("adminSettings", JSON.stringify(newSettings))
  }

  const toggleUserAllowed = (userId: string) => {
    const updatedUsers = users.map((user) =>
      user.userId === Number.parseInt(userId) ? { ...user, allowed: !user.allowed } : user,
    )
    setUsers(updatedUsers)
    localStorage.setItem("users", JSON.stringify(updatedUsers))
  }

  const addFunds = () => {
    if (!selectedUser || !addFundAmount) return

    const amount = Number.parseFloat(addFundAmount)
    if (isNaN(amount) || amount <= 0) {
      alert("Please enter a valid amount")
      return
    }

    const updatedUsers = users.map((user) =>
      user.userId === selectedUser.userId ? { ...user, balance: user.balance + amount } : user,
    )

    setUsers(updatedUsers)
    localStorage.setItem("users", JSON.stringify(updatedUsers))

    const currentUser = localStorage.getItem("currentUser")
    if (currentUser) {
      const current = JSON.parse(currentUser)
      if (current.userId === selectedUser.userId) {
        current.balance += amount
        localStorage.setItem("currentUser", JSON.stringify(current))
      }
    }

    setAddFundAmount("")
    setSelectedUser(null)
    alert(`Successfully added $${amount} to ${selectedUser.fullName}'s account`)
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
        <Card className="bg-slate-900 border-slate-700 p-8 w-full max-w-md">
          <h1 className="text-3xl font-bold text-center text-amber-500 mb-6">Admin Login</h1>
          <div className="space-y-4">
            <div>
              <Label className="text-white">Admin Password</Label>
              <Input
                type="password"
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                className="bg-slate-800 border-slate-700 text-white"
                placeholder="Enter admin password"
              />
            </div>
            <Button onClick={handleAdminLogin} className="w-full bg-amber-600 hover:bg-amber-700">
              Login
            </Button>
            <p className="text-xs text-slate-500 text-center">Demo: password is "admin123"</p>
          </div>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-slate-950">
      <header className="bg-slate-900 border-b border-slate-700 p-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <h1 className="text-3xl font-bold text-amber-500">Admin Dashboard</h1>
          <Button
            onClick={() => setIsAuthenticated(false)}
            variant="outline"
            className="border-slate-700 text-slate-300"
          >
            Logout
          </Button>
        </div>
      </header>

      <div className="max-w-7xl mx-auto p-8 space-y-8">
        {/* Global Settings */}
        <Card className="bg-slate-900 border-slate-700 p-6">
          <h2 className="text-2xl font-bold text-white mb-4">Global Settings</h2>
          <div className="flex items-center justify-between bg-slate-800/50 p-4 rounded-lg">
            <div>
              <p className="text-white font-semibold">Profitable Trades</p>
              <p className="text-sm text-slate-400">Control whether users can make profitable trades</p>
            </div>
            <div className="flex items-center gap-3">
              <span
                className={`text-sm font-semibold ${adminSettings.profitableTradesEnabled ? "text-emerald-500" : "text-red-500"}`}
              >
                {adminSettings.profitableTradesEnabled ? "ON" : "OFF"}
              </span>
              <Switch checked={adminSettings.profitableTradesEnabled} onCheckedChange={toggleProfitableTrades} />
            </div>
          </div>
        </Card>

        {/* User Management */}
        <Card className="bg-slate-900 border-slate-700 p-6">
          <h2 className="text-2xl font-bold text-white mb-4">Registered Users ({users.length})</h2>
          <div className="space-y-3">
            {users.map((user) => (
              <div key={user.userId} className="bg-slate-800/50 p-4 rounded-lg">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3">
                      <span className="text-white font-semibold">{user.fullName}</span>
                      <span className="text-xs bg-slate-700 text-slate-300 px-2 py-1 rounded">ID: {user.userId}</span>
                    </div>
                    <p className="text-sm text-slate-400">{user.email}</p>
                    <p className="text-sm text-amber-500 font-semibold mt-1">
                      Balance: ${user.balance.toLocaleString()}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-2">
                      <span className={`text-sm font-semibold ${user.allowed ? "text-emerald-500" : "text-red-500"}`}>
                        {user.allowed ? "Allowed" : "Blocked"}
                      </span>
                      <Switch checked={user.allowed || false} onCheckedChange={() => toggleUserAllowed(user.userId)} />
                    </div>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button onClick={() => setSelectedUser(user)} className="bg-amber-600 hover:bg-amber-700">
                          Add Funds
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="bg-slate-900 border-slate-700">
                        <DialogHeader>
                          <DialogTitle className="text-white">Add Funds to {user.fullName}</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <Label className="text-white">Current Balance</Label>
                            <p className="text-2xl font-bold text-amber-500">${user.balance.toLocaleString()}</p>
                          </div>
                          <div>
                            <Label className="text-white">Amount to Add</Label>
                            <Input
                              type="number"
                              value={addFundAmount}
                              onChange={(e) => setAddFundAmount(e.target.value)}
                              placeholder="Enter amount"
                              className="bg-slate-800 border-slate-700 text-white"
                            />
                          </div>
                          <Button onClick={addFunds} className="w-full bg-emerald-600 hover:bg-emerald-700">
                            Confirm Add Funds
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </div>
            ))}
            {users.length === 0 && <p className="text-center text-slate-400 py-8">No users registered yet</p>}
          </div>
        </Card>

        {/* Customer Messages */}
        <Card className="bg-slate-900 border-slate-700 p-6">
          <h2 className="text-2xl font-bold text-white mb-4">Customer Messages ({customerMessages.length})</h2>
          <div className="space-y-3">
            {customerMessages.map((msg) => (
              <div key={msg.id} className="bg-slate-800/50 p-4 rounded-lg">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-white font-semibold">{msg.userName}</span>
                      <span className="text-xs bg-slate-700 text-slate-300 px-2 py-1 rounded">
                        User ID: {msg.userId}
                      </span>
                      <span className="text-xs text-slate-400">{new Date(msg.timestamp).toLocaleString()}</span>
                    </div>
                    <p className="text-sm text-slate-400 mb-1">{msg.userEmail}</p>
                    <p className="text-white bg-slate-700/50 p-3 rounded mt-2">{msg.message}</p>
                    {msg.reply && (
                      <div className="mt-2 bg-emerald-900/20 p-3 rounded border border-emerald-700/30">
                        <p className="text-xs text-emerald-400 mb-1">Admin Reply:</p>
                        <p className="text-sm text-white">{msg.reply}</p>
                      </div>
                    )}
                  </div>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button
                        onClick={() => setSelectedMessage(msg)}
                        className="bg-blue-600 hover:bg-blue-700"
                        size="sm"
                      >
                        {msg.reply ? "View Reply" : "Reply"}
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="bg-slate-900 border-slate-700">
                      <DialogHeader>
                        <DialogTitle className="text-white">Reply to {msg.userName}</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <Label className="text-white">Original Message</Label>
                          <p className="text-sm text-slate-300 bg-slate-800 p-3 rounded mt-2">{msg.message}</p>
                        </div>
                        <div>
                          <Label className="text-white">Your Reply</Label>
                          <textarea
                            value={replyMessage}
                            onChange={(e) => setReplyMessage(e.target.value)}
                            placeholder="Type your reply..."
                            className="w-full p-3 bg-slate-800 border-slate-700 text-white rounded mt-2 resize-none"
                            rows={4}
                          />
                        </div>
                        <Button
                          onClick={() => {
                            const updatedMessages = customerMessages.map((m) =>
                              m.id === msg.id ? { ...m, reply: replyMessage, replied: true } : m,
                            )
                            setCustomerMessages(updatedMessages)
                            localStorage.setItem("customerMessages", JSON.stringify(updatedMessages))
                            setReplyMessage("")
                            setSelectedMessage(null)
                            alert("Reply sent successfully!")
                          }}
                          className="w-full bg-emerald-600 hover:bg-emerald-700"
                        >
                          Send Reply
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
            ))}
            {customerMessages.length === 0 && (
              <p className="text-center text-slate-400 py-8">No customer messages yet</p>
            )}
          </div>
        </Card>
      </div>
    </div>
  )
}
