"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

export default function AIArbitragePage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)

  useEffect(() => {
    const currentUser = localStorage.getItem("currentUser")
    if (!currentUser) {
      router.push("/login")
      return
    }
    setUser(JSON.parse(currentUser))
  }, [router])

  if (!user) {
    return null
  }

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Header */}
      <header className="bg-slate-900 border-b border-slate-700 p-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button onClick={() => router.push("/dashboard")} variant="ghost" className="text-slate-300">
              ← Back to Dashboard
            </Button>
            <h1 className="text-2xl font-bold text-blue-500">AI Arbitrage Trading</h1>
          </div>
          <div className="text-right">
            <p className="font-semibold text-white">{user.fullName}</p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-5xl mx-auto p-8">
        <div className="space-y-8">
          {/* Introduction */}
          <Card className="bg-gradient-to-br from-blue-950/50 to-slate-900 border-blue-500/30 p-8">
            <div className="flex items-start gap-4">
              <div className="w-16 h-16 bg-blue-600/20 rounded-full flex items-center justify-center flex-shrink-0">
                <svg className="w-8 h-8 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"
                  />
                </svg>
              </div>
              <div>
                <h2 className="text-3xl font-bold text-white mb-4">What is AI Arbitrage Trading?</h2>
                <p className="text-slate-300 text-lg leading-relaxed">
                  AI Arbitrage Trading is a sophisticated financial strategy that leverages artificial intelligence and
                  machine learning algorithms to identify and exploit price differences across multiple markets and
                  exchanges simultaneously. This automated approach enables traders to capitalize on temporary market
                  inefficiencies with unprecedented speed and accuracy.
                </p>
              </div>
            </div>
          </Card>

          {/* How It Works */}
          <Card className="bg-slate-900 border-slate-700 p-8">
            <h2 className="text-2xl font-bold text-amber-500 mb-6">How AI Arbitrage Works</h2>
            <div className="space-y-6">
              <div className="flex gap-4">
                <div className="w-12 h-12 bg-amber-600/20 rounded-lg flex items-center justify-center flex-shrink-0 text-amber-500 font-bold text-xl">
                  1
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white mb-2">Real-Time Market Scanning</h3>
                  <p className="text-slate-300 leading-relaxed">
                    Advanced AI algorithms continuously monitor price movements across hundreds of cryptocurrency
                    exchanges, commodity markets, and financial platforms 24/7. The system processes millions of data
                    points per second, identifying minute price discrepancies that human traders would miss.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-12 h-12 bg-amber-600/20 rounded-lg flex items-center justify-center flex-shrink-0 text-amber-500 font-bold text-xl">
                  2
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white mb-2">Price Difference Detection</h3>
                  <p className="text-slate-300 leading-relaxed">
                    When the AI detects a profitable price difference for the same asset on different exchanges, it
                    calculates the potential profit after accounting for transaction fees, slippage, and network costs.
                    The system uses predictive modeling to ensure the opportunity remains profitable throughout the
                    execution.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-12 h-12 bg-amber-600/20 rounded-lg flex items-center justify-center flex-shrink-0 text-amber-500 font-bold text-xl">
                  3
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white mb-2">Automated Execution</h3>
                  <p className="text-slate-300 leading-relaxed">
                    The AI executes simultaneous buy and sell orders across different markets in milliseconds. For
                    example, if Bitcoin is trading at $85,700 on Exchange A and $85,850 on Exchange B, the AI instantly
                    buys on A and sells on B, capturing the $150 difference before the market equilibrates.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-12 h-12 bg-amber-600/20 rounded-lg flex items-center justify-center flex-shrink-0 text-amber-500 font-bold text-xl">
                  4
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white mb-2">Risk Management</h3>
                  <p className="text-slate-300 leading-relaxed">
                    Built-in risk management protocols ensure that positions are balanced, exposure is limited, and
                    market volatility is accounted for. The AI continuously adjusts strategies based on market
                    conditions, liquidity levels, and historical performance data.
                  </p>
                </div>
              </div>
            </div>
          </Card>

          {/* Advantages */}
          <Card className="bg-slate-900 border-slate-700 p-8">
            <h2 className="text-2xl font-bold text-emerald-500 mb-6">Advantages of AI Arbitrage</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-slate-800/50 p-6 rounded-lg">
                <div className="w-10 h-10 bg-emerald-600/20 rounded-lg flex items-center justify-center mb-4">
                  <svg className="w-6 h-6 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </div>
                <h3 className="text-lg font-bold text-white mb-2">Lightning-Fast Execution</h3>
                <p className="text-slate-400">
                  AI can execute trades in microseconds, capturing opportunities that disappear within seconds. Human
                  traders cannot compete with this speed.
                </p>
              </div>

              <div className="bg-slate-800/50 p-6 rounded-lg">
                <div className="w-10 h-10 bg-emerald-600/20 rounded-lg flex items-center justify-center mb-4">
                  <svg className="w-6 h-6 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                </div>
                <h3 className="text-lg font-bold text-white mb-2">24/7 Operation</h3>
                <p className="text-slate-400">
                  Unlike human traders who need rest, AI systems work around the clock, never missing an opportunity
                  regardless of time zone or market hours.
                </p>
              </div>

              <div className="bg-slate-800/50 p-6 rounded-lg">
                <div className="w-10 h-10 bg-emerald-600/20 rounded-lg flex items-center justify-center mb-4">
                  <svg className="w-6 h-6 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                    />
                  </svg>
                </div>
                <h3 className="text-lg font-bold text-white mb-2">Reduced Risk</h3>
                <p className="text-slate-400">
                  Arbitrage is generally considered lower risk because you're simultaneously buying and selling,
                  minimizing exposure to market direction.
                </p>
              </div>

              <div className="bg-slate-800/50 p-6 rounded-lg">
                <div className="w-10 h-10 bg-emerald-600/20 rounded-lg flex items-center justify-center mb-4">
                  <svg className="w-6 h-6 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M7 12l3-3 3 3 4-4M8 21l4-4 4 4M3 4h18M4 4h16v12a1 1 0 01-1 1H5a1 1 0 01-1-1V4z"
                    />
                  </svg>
                </div>
                <h3 className="text-lg font-bold text-white mb-2">Data-Driven Decisions</h3>
                <p className="text-slate-400">
                  AI eliminates emotional trading by making decisions based purely on data, statistics, and proven
                  algorithms without fear or greed.
                </p>
              </div>

              <div className="bg-slate-800/50 p-6 rounded-lg">
                <div className="w-10 h-10 bg-emerald-600/20 rounded-lg flex items-center justify-center mb-4">
                  <svg className="w-6 h-6 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M3 15a4 4 0 004 4h9a5 5 0 10-.1-9.999 5.002 5.002 0 10-9.78 2.096A4.001 4.001 0 003 15z"
                    />
                  </svg>
                </div>
                <h3 className="text-lg font-bold text-white mb-2">Scalability</h3>
                <p className="text-slate-400">
                  AI systems can monitor and trade across unlimited markets simultaneously, scaling operations far
                  beyond human capabilities.
                </p>
              </div>

              <div className="bg-slate-800/50 p-6 rounded-lg">
                <div className="w-10 h-10 bg-emerald-600/20 rounded-lg flex items-center justify-center mb-4">
                  <svg className="w-6 h-6 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                    />
                  </svg>
                </div>
                <h3 className="text-lg font-bold text-white mb-2">Continuous Learning</h3>
                <p className="text-slate-400">
                  Machine learning algorithms improve over time, adapting to market changes and optimizing strategies
                  based on historical performance.
                </p>
              </div>
            </div>
          </Card>

          {/* Types of Arbitrage */}
          <Card className="bg-slate-900 border-slate-700 p-8">
            <h2 className="text-2xl font-bold text-blue-500 mb-6">Types of AI Arbitrage Strategies</h2>
            <div className="space-y-6">
              <div className="bg-slate-800/30 p-6 rounded-lg border border-slate-700">
                <h3 className="text-xl font-bold text-white mb-3">Spatial Arbitrage</h3>
                <p className="text-slate-300 leading-relaxed">
                  Exploiting price differences for the same asset across different exchanges or geographic locations.
                  For example, Bitcoin might trade at slightly different prices on Binance, Coinbase, and Kraken
                  simultaneously.
                </p>
              </div>

              <div className="bg-slate-800/30 p-6 rounded-lg border border-slate-700">
                <h3 className="text-xl font-bold text-white mb-3">Triangular Arbitrage</h3>
                <p className="text-slate-300 leading-relaxed">
                  Taking advantage of price discrepancies between three different cryptocurrencies. For instance,
                  converting USD to BTC, then BTC to ETH, then ETH back to USD, profiting from exchange rate
                  inefficiencies.
                </p>
              </div>

              <div className="bg-slate-800/30 p-6 rounded-lg border border-slate-700">
                <h3 className="text-xl font-bold text-white mb-3">Statistical Arbitrage</h3>
                <p className="text-slate-300 leading-relaxed">
                  Using complex mathematical models and historical data to identify pairs of assets that typically move
                  together. When they temporarily diverge, the AI goes long on the undervalued asset and short on the
                  overvalued one, profiting when they converge.
                </p>
              </div>

              <div className="bg-slate-800/30 p-6 rounded-lg border border-slate-700">
                <h3 className="text-xl font-bold text-white mb-3">Latency Arbitrage</h3>
                <p className="text-slate-300 leading-relaxed">
                  Exploiting time delays in price updates across different exchanges. AI systems with superior
                  infrastructure can see and act on price changes microseconds before they appear on other platforms.
                </p>
              </div>
            </div>
          </Card>

          {/* Platform Integration */}
          <Card className="bg-gradient-to-br from-amber-950/50 to-slate-900 border-amber-500/30 p-8">
            <h2 className="text-2xl font-bold text-amber-500 mb-4">AI Arbitrage on Our Platform</h2>
            <p className="text-slate-300 leading-relaxed mb-6">
              Our platform integrates cutting-edge AI arbitrage technology to provide users with access to
              institutional-grade trading strategies. When you trade with us, you benefit from:
            </p>
            <ul className="space-y-3 text-slate-300">
              <li className="flex items-start gap-3">
                <div className="w-6 h-6 bg-amber-600/20 rounded flex items-center justify-center flex-shrink-0 mt-0.5">
                  <svg className="w-4 h-4 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <span>AI-powered price optimization ensuring you always get competitive entry and exit prices</span>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-6 h-6 bg-amber-600/20 rounded flex items-center justify-center flex-shrink-0 mt-0.5">
                  <svg className="w-4 h-4 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <span>Real-time market analysis across multiple exchanges to find the best trading opportunities</span>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-6 h-6 bg-amber-600/20 rounded flex items-center justify-center flex-shrink-0 mt-0.5">
                  <svg className="w-4 h-4 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <span>Guaranteed profit mechanisms on our platform through algorithmic price adjustments</span>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-6 h-6 bg-amber-600/20 rounded flex items-center justify-center flex-shrink-0 mt-0.5">
                  <svg className="w-4 h-4 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <span>Advanced risk management systems that protect your capital while maximizing returns</span>
              </li>
            </ul>
          </Card>
        </div>
      </div>
    </div>
  )
}
