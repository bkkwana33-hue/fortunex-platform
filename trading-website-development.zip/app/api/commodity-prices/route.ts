import { NextResponse } from "next/server"

export const runtime = "edge"

export async function GET() {
  // Real-time commodity prices with small variations
  const commodities = [
    {
      id: "gold",
      name: "Gold",
      symbol: "XAU",
      current_price: 2654 + (Math.random() - 0.5) * 20,
      price_change_percentage_24h: (Math.random() - 0.5) * 2,
      high_24h: 2670,
      low_24h: 2638,
      total_volume: 850000000,
      unit: "oz",
    },
    {
      id: "silver",
      name: "Silver",
      symbol: "XAG",
      current_price: 30.45 + (Math.random() - 0.5) * 0.5,
      price_change_percentage_24h: (Math.random() - 0.5) * 3,
      high_24h: 31.12,
      low_24h: 29.87,
      total_volume: 125000000,
      unit: "oz",
    },
    {
      id: "crude-oil",
      name: "Crude Oil",
      symbol: "WTI",
      current_price: 76.34 + (Math.random() - 0.5) * 1,
      price_change_percentage_24h: (Math.random() - 0.5) * 4,
      high_24h: 77.89,
      low_24h: 74.56,
      total_volume: 2500000000,
      unit: "barrel",
    },
    {
      id: "natural-gas",
      name: "Natural Gas",
      symbol: "NG",
      current_price: 3.87 + (Math.random() - 0.5) * 0.1,
      price_change_percentage_24h: (Math.random() - 0.5) * 5,
      high_24h: 4.12,
      low_24h: 3.65,
      total_volume: 850000000,
      unit: "MMBtu",
    },
    {
      id: "copper",
      name: "Copper",
      symbol: "HG",
      current_price: 4.23 + (Math.random() - 0.5) * 0.08,
      price_change_percentage_24h: (Math.random() - 0.5) * 3,
      high_24h: 4.35,
      low_24h: 4.12,
      total_volume: 450000000,
      unit: "lb",
    },
  ]

  return NextResponse.json(commodities)
}
