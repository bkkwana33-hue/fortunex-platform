import { NextResponse } from "next/server"

export const runtime = "edge"

export async function GET() {
  // Simulated real-time prices with small variations to mimic live market
  const basePrices = {
    bitcoin: 85700,
    ethereum: 3245,
    binancecoin: 598,
    ripple: 2.12,
    solana: 178,
    dogecoin: 0.32,
    cardano: 0.89,
    "pax-gold": 2654,
  }

  const formattedData = [
    {
      id: "bitcoin",
      current_price: basePrices.bitcoin + (Math.random() - 0.5) * 500,
      price_change_percentage_24h: (Math.random() - 0.5) * 6,
      high_24h: 87200,
      low_24h: 84100,
      total_volume: 45000000000,
      market_cap: 1950000000000,
    },
    {
      id: "ethereum",
      current_price: basePrices.ethereum + (Math.random() - 0.5) * 50,
      price_change_percentage_24h: (Math.random() - 0.5) * 6,
      high_24h: 3310,
      low_24h: 3180,
      total_volume: 18000000000,
      market_cap: 415000000000,
    },
    {
      id: "binancecoin",
      current_price: basePrices.binancecoin + (Math.random() - 0.5) * 10,
      price_change_percentage_24h: (Math.random() - 0.5) * 6,
      high_24h: 610,
      low_24h: 586,
      total_volume: 2000000000,
      market_cap: 94000000000,
    },
    {
      id: "ripple",
      current_price: basePrices.ripple + (Math.random() - 0.5) * 0.1,
      price_change_percentage_24h: (Math.random() - 0.5) * 6,
      high_24h: 2.18,
      low_24h: 2.06,
      total_volume: 3500000000,
      market_cap: 120000000000,
    },
    {
      id: "solana",
      current_price: basePrices.solana + (Math.random() - 0.5) * 5,
      price_change_percentage_24h: (Math.random() - 0.5) * 6,
      high_24h: 182,
      low_24h: 174,
      total_volume: 4500000000,
      market_cap: 85000000000,
    },
    {
      id: "dogecoin",
      current_price: basePrices.dogecoin + (Math.random() - 0.5) * 0.02,
      price_change_percentage_24h: (Math.random() - 0.5) * 6,
      high_24h: 0.33,
      low_24h: 0.31,
      total_volume: 1200000000,
      market_cap: 48000000000,
    },
    {
      id: "cardano",
      current_price: basePrices.cardano + (Math.random() - 0.5) * 0.05,
      price_change_percentage_24h: (Math.random() - 0.5) * 6,
      high_24h: 0.92,
      low_24h: 0.86,
      total_volume: 1100000000,
      market_cap: 32000000000,
    },
    {
      id: "pax-gold",
      current_price: basePrices["pax-gold"] + (Math.random() - 0.5) * 20,
      price_change_percentage_24h: (Math.random() - 0.5) * 2,
      high_24h: 2670,
      low_24h: 2638,
      total_volume: 850000000,
      market_cap: 525000000,
    },
  ]

  return NextResponse.json(formattedData)
}
