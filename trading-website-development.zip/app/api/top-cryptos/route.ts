import { NextResponse } from "next/server"

export async function GET() {
  try {
    // Try to fetch from CoinGecko API
    const response = await fetch(
      "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=30&page=1&sparkline=false&price_change_percentage=24h",
      {
        headers: {
          Accept: "application/json",
        },
        next: { revalidate: 10 }, // Cache for 10 seconds
      },
    )

    if (response.ok) {
      const data = await response.json()
      return NextResponse.json(data)
    }

    // Fallback to mock data if API fails
    return NextResponse.json(getMockTop30Cryptos())
  } catch (error) {
    console.error("Error fetching top cryptos:", error)
    return NextResponse.json(getMockTop30Cryptos())
  }
}

function getMockTop30Cryptos() {
  const basePrices = [
    { id: "bitcoin", symbol: "btc", name: "Bitcoin", price: 85700, marketCap: 1690000000000, volume: 42000000000 },
    { id: "ethereum", symbol: "eth", name: "Ethereum", price: 3245, marketCap: 390000000000, volume: 18000000000 },
    { id: "tether", symbol: "usdt", name: "Tether", price: 1.0, marketCap: 140000000000, volume: 85000000000 },
    { id: "binancecoin", symbol: "bnb", name: "BNB", price: 628, marketCap: 92000000000, volume: 1900000000 },
    { id: "solana", symbol: "sol", name: "Solana", price: 142, marketCap: 71000000000, volume: 3200000000 },
    { id: "usd-coin", symbol: "usdc", name: "USDC", price: 1.0, marketCap: 58000000000, volume: 7800000000 },
    { id: "ripple", symbol: "xrp", name: "XRP", price: 2.45, marketCap: 142000000000, volume: 5400000000 },
    { id: "cardano", symbol: "ada", name: "Cardano", price: 0.89, marketCap: 31000000000, volume: 980000000 },
    { id: "dogecoin", symbol: "doge", name: "Dogecoin", price: 0.31, marketCap: 46000000000, volume: 4200000000 },
    { id: "tron", symbol: "trx", name: "TRON", price: 0.24, marketCap: 21000000000, volume: 580000000 },
    {
      id: "chainlink",
      symbol: "link",
      name: "Chainlink",
      price: 21.5,
      marketCap: 13400000000,
      volume: 680000000,
    },
    { id: "avalanche", symbol: "avax", name: "Avalanche", price: 35.8, marketCap: 15200000000, volume: 520000000 },
    { id: "polkadot", symbol: "dot", name: "Polkadot", price: 6.85, marketCap: 10200000000, volume: 310000000 },
    { id: "polygon", symbol: "matic", name: "Polygon", price: 0.48, marketCap: 4800000000, volume: 240000000 },
    {
      id: "wrapped-bitcoin",
      symbol: "wbtc",
      name: "Wrapped Bitcoin",
      price: 85650,
      marketCap: 13500000000,
      volume: 420000000,
    },
    { id: "litecoin", symbol: "ltc", name: "Litecoin", price: 105, marketCap: 7900000000, volume: 580000000 },
    {
      id: "shiba-inu",
      symbol: "shib",
      name: "Shiba Inu",
      price: 0.00002145,
      marketCap: 12600000000,
      volume: 680000000,
    },
    { id: "dai", symbol: "dai", name: "Dai", price: 1.0, marketCap: 5200000000, volume: 380000000 },
    { id: "uniswap", symbol: "uni", name: "Uniswap", price: 12.5, marketCap: 7500000000, volume: 280000000 },
    { id: "cosmos", symbol: "atom", name: "Cosmos Hub", price: 6.45, marketCap: 2500000000, volume: 180000000 },
    {
      id: "ethereum-classic",
      symbol: "etc",
      name: "Ethereum Classic",
      price: 26.8,
      marketCap: 4000000000,
      volume: 290000000,
    },
    { id: "stellar", symbol: "xlm", name: "Stellar", price: 0.385, marketCap: 11300000000, volume: 420000000 },
    { id: "monero", symbol: "xmr", name: "Monero", price: 218, marketCap: 4000000000, volume: 120000000 },
    {
      id: "okb",
      symbol: "okb",
      name: "OKB",
      price: 48.5,
      marketCap: 2900000000,
      volume: 95000000,
    },
    { id: "filecoin", symbol: "fil", name: "Filecoin", price: 4.82, marketCap: 2800000000, volume: 180000000 },
    { id: "hedera", symbol: "hbar", name: "Hedera", price: 0.28, marketCap: 10500000000, volume: 340000000 },
    { id: "aptos", symbol: "apt", name: "Aptos", price: 8.95, marketCap: 4500000000, volume: 210000000 },
    { id: "vechain", symbol: "vet", name: "VeChain", price: 0.048, marketCap: 3900000000, volume: 140000000 },
    { id: "near", symbol: "near", name: "NEAR Protocol", price: 4.65, marketCap: 5600000000, volume: 280000000 },
    { id: "arbitrum", symbol: "arb", name: "Arbitrum", price: 0.78, marketCap: 3100000000, volume: 190000000 },
  ]

  return basePrices.map((crypto) => {
    const variation = (Math.random() - 0.5) * 0.02
    const current_price = crypto.price * (1 + variation)
    const price_change_24h = (Math.random() - 0.3) * 15

    return {
      id: crypto.id,
      symbol: crypto.symbol,
      name: crypto.name,
      current_price,
      price_change_percentage_24h: price_change_24h,
      market_cap: crypto.marketCap * (1 + variation),
      total_volume: crypto.volume * (1 + Math.random() * 0.3),
      high_24h: current_price * 1.05,
      low_24h: current_price * 0.95,
    }
  })
}
