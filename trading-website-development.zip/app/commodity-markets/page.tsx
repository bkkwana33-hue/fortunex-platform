"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

interface Commodity {
  id: string
  name: string
  symbol: string
  current_price: number
  price_change_percentage_24h: number
  high_24h: number
  low_24h: number
  total_volume: number
  unit: string
}

export default function CommodityMarketsPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [commodities, setCommodities] = useState<Commodity[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const currentUser = localStorage.getItem("currentUser")
    if (!currentUser) {
      router.push("/login")
      return
    }
    setUser(JSON.parse(currentUser))

    loadCommodities()
    const interval = setInterval(loadCommodities, 5000)
    return () => clearInterval(interval)
  }, [router])

  const loadCommodities = async () => {
    try {
      const response = await fetch("/api/commodity-prices")
      const data = await response.json()
      setCommodities(data)
      setLoading(false)
    } catch (error) {
      console.error("Error loading commodities:", error)
      setLoading(false)
    }
  }

  if (!user) {
    return null
  }

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Header */}
      <header className="bg-slate-900 border-b border-slate-700 p-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <h1 className="text-2xl font-bold text-amber-500">TradePro - Commodity Markets</h1>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="text-sm text-slate-400">Balance</p>
              <p className="font-bold text-amber-500">${user.balance?.toLocaleString() || "10,000"}</p>
            </div>
            <Button onClick={() => router.push("/dashboard")} variant="outline">
              Back to Dashboard
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto p-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">Top 5 Global Commodities</h2>
          <p className="text-slate-400">Trade the world's most popular commodities with real-time prices</p>
        </div>

        {loading ? (
          <div className="grid gap-4">
            {[...Array(5)].map((_, i) => (
              <Card key={i} className="bg-slate-900 border-slate-700 animate-pulse">
                <CardContent className="p-6">
                  <div className="h-24 bg-slate-800 rounded" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid gap-4">
            {commodities.map((commodity) => (
              <Card
                key={commodity.id}
                className="bg-slate-900 border-slate-700 hover:bg-slate-800 transition-all cursor-pointer"
                onClick={() => router.push(`/trading-commodity/${commodity.symbol}`)}
              >
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 bg-orange-600/20 rounded-full flex items-center justify-center">
                          <span className="text-xl font-bold text-orange-500">{commodity.symbol}</span>
                        </div>
                        <div>
                          <h3 className="text-xl font-bold text-white">
                            {commodity.name} ({commodity.symbol})
                          </h3>
                          <p className="text-sm text-slate-400">Per {commodity.unit}</p>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-8">
                      <div className="text-right">
                        <p className="text-sm text-slate-400">Current Price</p>
                        <p className="text-2xl font-bold text-white">${commodity.current_price.toFixed(2)}</p>
                      </div>

                      <div className="text-right">
                        <p className="text-sm text-slate-400">24h Change</p>
                        <p
                          className={`text-xl font-semibold ${
                            commodity.price_change_percentage_24h >= 0 ? "text-emerald-500" : "text-red-500"
                          }`}
                        >
                          {commodity.price_change_percentage_24h >= 0 ? "↑" : "↓"}{" "}
                          {Math.abs(commodity.price_change_percentage_24h).toFixed(2)}%
                        </p>
                      </div>

                      <div className="text-right">
                        <p className="text-sm text-slate-400">24h High/Low</p>
                        <p className="text-sm text-white">
                          ${commodity.high_24h.toFixed(2)} / ${commodity.low_24h.toFixed(2)}
                        </p>
                      </div>

                      <Button className="bg-amber-600 hover:bg-amber-700">Trade Now</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
