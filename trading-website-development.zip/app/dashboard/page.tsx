"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

export default function DashboardPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)

  useEffect(() => {
    const currentUser = localStorage.getItem("currentUser")
    if (!currentUser) {
      router.push("/login")
      return
    }
    setUser(JSON.parse(currentUser))
  }, [router])

  if (!user) {
    return null
  }

  return (
    <div className="min-h-screen relative">
      {/* Background with gold image */}
      <div
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: "url(/images/gold-bitcoin.jpg)",
          backgroundSize: "cover",
          backgroundPosition: "center",
          filter: "blur(8px) brightness(0.4)",
        }}
      />

      <div className="relative z-10 min-h-screen">
        {/* Header */}
        <header className="bg-slate-900/80 backdrop-blur-sm border-b border-slate-700 p-4">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <h1 className="text-2xl font-bold text-amber-500">TradePro</h1>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-sm text-slate-400">Welcome back</p>
                <p className="font-semibold text-white">{user.fullName}</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-slate-400">Balance</p>
                <p className="font-bold text-amber-500">${user.balance?.toLocaleString() || "10,000"}</p>
              </div>
              <Button
                onClick={() => router.push("/profile")}
                variant="outline"
                className="border-amber-700 text-amber-400 hover:bg-amber-900/20"
              >
                Profile
              </Button>
              <Button
                onClick={() => {
                  localStorage.removeItem("currentUser")
                  router.push("/landing")
                }}
                variant="outline"
                className="border-slate-700 text-slate-300 hover:bg-slate-800"
              >
                Logout
              </Button>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <div className="max-w-7xl mx-auto p-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Trade Button */}
            <Card
              className="bg-slate-900/80 backdrop-blur border-slate-700 p-8 hover:bg-slate-800/80 transition-all cursor-pointer group"
              onClick={() => router.push("/trade-list")}
            >
              <div className="text-center space-y-4">
                <div className="w-20 h-20 mx-auto bg-amber-600/20 rounded-full flex items-center justify-center group-hover:bg-amber-600/30 transition-colors">
                  <svg className="w-10 h-10 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"
                    />
                  </svg>
                </div>
                <h2 className="text-2xl font-bold text-white">Trade</h2>
                <p className="text-slate-400">Start trading cryptocurrencies and gold</p>
              </div>
            </Card>

            {/* Security Button */}
            <Card
              className="bg-slate-900/80 backdrop-blur border-slate-700 p-8 hover:bg-slate-800/80 transition-all cursor-pointer group"
              onClick={() => router.push("/security")}
            >
              <div className="text-center space-y-4">
                <div className="w-20 h-20 mx-auto bg-purple-600/20 rounded-full flex items-center justify-center group-hover:bg-purple-600/30 transition-colors">
                  <svg className="w-10 h-10 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                    />
                  </svg>
                </div>
                <h2 className="text-2xl font-bold text-white">Security</h2>
                <p className="text-slate-400">Manage your password and profile</p>
              </div>
            </Card>

            {/* AI Arbitrage Button */}
            <Card
              className="bg-slate-900/80 backdrop-blur border-slate-700 p-8 hover:bg-slate-800/80 transition-all cursor-pointer group"
              onClick={() => router.push("/ai-arbitrage")}
            >
              <div className="text-center space-y-4">
                <div className="w-20 h-20 mx-auto bg-blue-600/20 rounded-full flex items-center justify-center group-hover:bg-blue-600/30 transition-colors">
                  <svg className="w-10 h-10 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"
                    />
                  </svg>
                </div>
                <h2 className="text-2xl font-bold text-white">AI Arbitrage</h2>
                <p className="text-slate-400">Learn about AI-powered trading</p>
              </div>
            </Card>

            {/* Market Analysis Center Button */}
            <Card
              className="bg-slate-900/80 backdrop-blur border-slate-700 p-8 hover:bg-slate-800/80 transition-all cursor-pointer group"
              onClick={() => router.push("/market-analysis")}
            >
              <div className="text-center space-y-4">
                <div className="w-20 h-20 mx-auto bg-emerald-600/20 rounded-full flex items-center justify-center group-hover:bg-emerald-600/30 transition-colors">
                  <svg className="w-10 h-10 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                    />
                  </svg>
                </div>
                <h2 className="text-2xl font-bold text-white">Market Analysis</h2>
                <p className="text-slate-400">Real-time market K-charts</p>
              </div>
            </Card>

            {/* Market Review Button (keeping original) */}
            <Card
              className="bg-slate-900/80 backdrop-blur border-slate-700 p-8 hover:bg-slate-800/80 transition-all cursor-pointer group"
              onClick={() => router.push("/market-review")}
            >
              <div className="text-center space-y-4">
                <div className="w-20 h-20 mx-auto bg-cyan-600/20 rounded-full flex items-center justify-center group-hover:bg-cyan-600/30 transition-colors">
                  <svg className="w-10 h-10 text-cyan-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M7 12l3-3 3 3 4-4M8 21l4-4 4 4M3 4h18M4 4h16v12a1 1 0 00-5.356-1.857M7 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                    />
                  </svg>
                </div>
                <h2 className="text-2xl font-bold text-white">Market Review</h2>
                <p className="text-slate-400">View detailed market overview</p>
              </div>
            </Card>

            {/* Commodity Markets Button */}
            <Card
              className="bg-slate-900/80 backdrop-blur border-slate-700 p-8 hover:bg-slate-800/80 transition-all cursor-pointer group"
              onClick={() => router.push("/commodity-markets")}
            >
              <div className="text-center space-y-4">
                <div className="w-20 h-20 mx-auto bg-orange-600/20 rounded-full flex items-center justify-center group-hover:bg-orange-600/30 transition-colors">
                  <svg className="w-10 h-10 text-orange-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"
                    />
                  </svg>
                </div>
                <h2 className="text-2xl font-bold text-white">Commodity Markets</h2>
                <p className="text-slate-400">Trade top 5 global commodities</p>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
