"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ImageSlideshow } from "@/components/landing/image-slideshow"
import { MarketMiniChart } from "@/components/landing/market-mini-chart"
import { DetailedChart } from "@/components/landing/detailed-chart"
import { TrendingUp, Mail, Info, Sparkles, Shield, Scale } from "lucide-react"
import { useEffect, useState } from "react"
import { fetchCryptoPrices, type CryptoPrice } from "@/lib/crypto-api"
import Link from "next/link"

export default function LandingPage() {
  const [prices, setPrices] = useState<CryptoPrice[]>([])
  const [selectedCoin, setSelectedCoin] = useState<CryptoPrice | null>(null)
  const [loading, setLoading] = useState(true)
  const [showCustomerService, setShowCustomerService] = useState(false)
  const [customerMessage, setCustomerMessage] = useState("")
  const [currentUser, setCurrentUser] = useState<any>(null)

  useEffect(() => {
    const loadPrices = async () => {
      const data = await fetchCryptoPrices()
      setPrices(data)
      setLoading(false)
    }

    const user = localStorage.getItem("currentUser")
    if (user) {
      setCurrentUser(JSON.parse(user))
    }

    loadPrices()
    const interval = setInterval(loadPrices, 15000)
    return () => clearInterval(interval)
  }, [])

  const sendCustomerMessage = () => {
    if (!customerMessage.trim()) return

    const messages = JSON.parse(localStorage.getItem("customerMessages") || "[]")
    const newMessage = {
      id: Date.now(),
      userId: currentUser?.userId || "guest",
      userName: currentUser?.fullName || "Guest User",
      userEmail: currentUser?.email || "No email",
      message: customerMessage,
      timestamp: new Date().toISOString(),
      replied: false,
    }
    messages.push(newMessage)
    localStorage.setItem("customerMessages", JSON.stringify(messages))

    setCustomerMessage("")
    alert("Message sent! Our team will respond shortly.")
  }

  const displayCoins = [
    prices.find((p) => p.symbol === "GOLD"),
    ...prices.filter((p) => p.symbol !== "GOLD").slice(0, 9),
  ].filter(Boolean) as CryptoPrice[]

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card/95 backdrop-blur sticky top-0 z-50">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-2 font-bold text-xl">
            <TrendingUp className="h-6 w-6 text-primary" />
            <span className="bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              Infinity Net
            </span>
          </div>

          <div className="flex gap-3">
            <Button variant="ghost" disabled className="cursor-default">
              Home Page
            </Button>
            <Button variant="outline" asChild>
              <Link href="/login">Login</Link>
            </Button>
            <Button asChild>
              <Link href="/signup">Sign Up</Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4">
        <section className="py-8">
          <ImageSlideshow />
          <div className="text-center mt-8">
            <h1
              className="text-5xl md:text-7xl font-black bg-gradient-to-r from-amber-500 via-orange-500 to-red-500 bg-clip-text text-transparent tracking-tight"
              style={{ fontFamily: "Impact, fantasy" }}
            >
              Let's Get Started
            </h1>
          </div>
        </section>

        <section className="py-12">
          <div className="grid md:grid-cols-3 gap-6">
            <Link href="/ai-arbitrage">
              <Card className="cursor-pointer hover:shadow-lg transition-all hover:scale-105 bg-gradient-to-br from-purple-500/10 to-pink-500/10 border-purple-500/20">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Sparkles className="h-6 w-6 text-purple-500" />
                    AI Arbitrage
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Learn how our advanced AI algorithms identify and execute profitable arbitrage opportunities across
                    markets in real-time.
                  </p>
                </CardContent>
              </Card>
            </Link>
          </div>
        </section>

        <section className="py-12">
          {loading ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
              {[...Array(10)].map((_, i) => (
                <Card key={i} className="animate-pulse">
                  <CardContent className="p-4">
                    <div className="h-32 bg-muted rounded" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
              {displayCoins.map((coin) => (
                <Card
                  key={coin.symbol}
                  className={`cursor-pointer transition-all hover:shadow-lg ${
                    selectedCoin?.symbol === coin.symbol ? "ring-2 ring-primary" : ""
                  }`}
                  onClick={() => setSelectedCoin(coin)}
                >
                  <CardHeader className="p-4 pb-2">
                    <CardTitle className="text-sm font-semibold flex items-center justify-between">
                      <span>{coin.symbol}</span>
                      {coin.symbol === "GOLD" && (
                        <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded">COMX</span>
                      )}
                    </CardTitle>
                    <div className="text-xs text-muted-foreground">{coin.name}</div>
                  </CardHeader>
                  <CardContent className="p-4 pt-2 space-y-2">
                    <div className="text-lg font-bold">${coin.price.toFixed(2)}</div>
                    <div className={`text-xs ${coin.change24h >= 0 ? "text-green-500" : "text-red-500"}`}>
                      {coin.change24h >= 0 ? "↑" : "↓"} {Math.abs(coin.change24h).toFixed(2)}%
                    </div>
                    <div className="text-xs text-muted-foreground">Vol: ${(coin.volume24h / 1000000).toFixed(1)}M</div>
                    <MarketMiniChart symbol={coin.symbol} currentPrice={coin.price} />
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </section>

        {selectedCoin && (
          <section className="py-12">
            <DetailedChart symbol={selectedCoin.symbol} name={selectedCoin.name} currentPrice={selectedCoin.price} />
          </section>
        )}

        <section className="py-12">
          <Card className="bg-gradient-to-br from-primary/5 to-primary/10">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-primary" />
                AI Market Analysis
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="prose prose-sm max-w-none">
                <p className="text-muted-foreground">
                  Our advanced AI algorithms analyze real-time market data across all assets, providing intelligent
                  insights and predictions to help you make informed trading decisions. The system monitors price
                  movements, volume trends, and market sentiment 24/7.
                </p>
                <div className="grid md:grid-cols-2 gap-4 mt-4">
                  <div className="p-4 bg-card rounded-lg border">
                    <h4 className="font-semibold mb-2">Market Sentiment</h4>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-muted rounded-full h-2">
                        <div className="bg-green-500 h-2 rounded-full" style={{ width: "65%" }} />
                      </div>
                      <span className="text-sm font-medium text-green-500">Bullish</span>
                    </div>
                  </div>
                  <div className="p-4 bg-card rounded-lg border">
                    <h4 className="font-semibold mb-2">Volatility Index</h4>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-muted rounded-full h-2">
                        <div className="bg-yellow-500 h-2 rounded-full" style={{ width: "45%" }} />
                      </div>
                      <span className="text-sm font-medium text-yellow-600">Moderate</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        <section className="py-12">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Info className="h-5 w-5" />
                About Us
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="prose prose-sm max-w-none text-muted-foreground">
                <p>
                  Infinity Net is a cutting-edge trading platform designed for both novice and experienced traders. We
                  offer innovative trading modes including Normal and Mega options, with quick 60s and 90s trading
                  intervals for fast-paced market action.
                </p>
                <p className="mt-4">
                  Our platform provides real-time market data for major cryptocurrencies and commodities like Gold,
                  ensuring you have access to accurate pricing information. With advanced charting tools and AI-powered
                  analysis, we empower traders to make data-driven decisions.
                </p>
                <div className="grid md:grid-cols-3 gap-4 mt-6">
                  <div className="text-center p-4 bg-muted/30 rounded-lg">
                    <div className="text-3xl font-bold text-primary">24/7</div>
                    <div className="text-sm mt-1">Trading Available</div>
                  </div>
                  <div className="text-center p-4 bg-muted/30 rounded-lg">
                    <div className="text-3xl font-bold text-primary">+100</div>
                    <div className="text-sm mt-1">Trading Assets</div>
                  </div>
                  <div className="text-center p-4 bg-muted/30 rounded-lg">
                    <div className="text-3xl font-bold text-primary">Real-Time</div>
                    <div className="text-sm mt-1">Market Data</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        <section className="py-12">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mail className="h-5 w-5" />
                Contact Us
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold mb-1">Customer Support</h4>
                    <p className="text-sm text-muted-foreground">support@infinitynet.com</p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Business Inquiries</h4>
                    <p className="text-sm text-muted-foreground">business@infinitynet.com</p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Trading Hours</h4>
                    <p className="text-sm text-muted-foreground">24/7 - Always Open</p>
                  </div>
                </div>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold mb-2">Quick Support</h4>
                    <p className="text-sm text-muted-foreground mb-3">
                      Have a question? Our support team is available around the clock to assist you.
                    </p>
                    <Button onClick={sendCustomerMessage} className="w-full">
                      Send Message
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        <section className="py-12">
          <h2 className="text-3xl font-bold mb-8 text-center">Platform Information</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <Link href="/risk-management">
              <Card className="cursor-pointer hover:shadow-lg transition-all hover:scale-105 bg-gradient-to-br from-blue-500/10 to-cyan-500/10 border-blue-500/20">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="h-6 w-6 text-blue-500" />
                    Risk Management
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Discover essential risk management strategies to protect your capital and maximize long-term trading
                    success.
                  </p>
                </CardContent>
              </Card>
            </Link>

            <Link href="/limits-legalization">
              <Card className="cursor-pointer hover:shadow-lg transition-all hover:scale-105 bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border-emerald-500/20">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Scale className="h-6 w-6 text-emerald-500" />
                    Limits & Legalization
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Understand the regulatory framework and legal authorities governing our trading platform operations.
                  </p>
                </CardContent>
              </Card>
            </Link>
          </div>
        </section>
      </main>

      <footer className="border-t py-8 mt-12">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>&copy; 2025 Infinity Net. All rights reserved.</p>
        </div>
      </footer>

      <button
        onClick={() => setShowCustomerService(!showCustomerService)}
        className="fixed bottom-6 right-6 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-full p-4 shadow-lg hover:shadow-xl transition-all hover:scale-110 z-50"
      >
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
          />
        </svg>
      </button>

      {showCustomerService && (
        <div className="fixed bottom-24 right-6 w-80 bg-card border rounded-lg shadow-2xl z-50">
          <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-4 rounded-t-lg flex items-center justify-between">
            <h3 className="font-semibold">Customer Service</h3>
            <button onClick={() => setShowCustomerService(false)} className="hover:bg-white/20 rounded p-1">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          <div className="p-4 space-y-4 max-h-96 overflow-y-auto">
            <div className="bg-muted p-3 rounded-lg">
              <p className="text-sm">Hello! How can we help you today?</p>
            </div>
          </div>
          <div className="p-4 border-t space-y-2">
            <textarea
              value={customerMessage}
              onChange={(e) => setCustomerMessage(e.target.value)}
              placeholder="Type your message..."
              className="w-full p-2 border rounded text-sm resize-none"
              rows={3}
            />
            <Button onClick={sendCustomerMessage} className="w-full">
              Send Message
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
