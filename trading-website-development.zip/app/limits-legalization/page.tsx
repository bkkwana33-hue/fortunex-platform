"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Scale, Building2, Shield, Globe } from "lucide-react"
import { useRouter } from "next/navigation"

export default function LimitsLegalizationPage() {
  const router = useRouter()

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <header className="bg-slate-900/80 backdrop-blur-sm border-b border-slate-700 p-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button onClick={() => router.push("/landing")} variant="ghost" className="text-slate-400 hover:text-white">
              ← Back
            </Button>
            <h1 className="text-2xl font-bold text-white flex items-center gap-2">
              <Scale className="h-6 w-6 text-emerald-500" />
              Limits & Legalization
            </h1>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto p-8">
        <Card className="bg-slate-900/80 backdrop-blur border-slate-700 mb-8">
          <CardHeader>
            <CardTitle className="text-3xl text-white">Regulatory Framework & Legal Authorities</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6 text-slate-300">
            <p className="text-lg leading-relaxed">
              Our trading platform operates within a comprehensive regulatory framework governed by multiple
              international authorities. These regulatory bodies ensure fair trading practices, market integrity,
              consumer protection, and compliance with financial regulations across jurisdictions.
            </p>
          </CardContent>
        </Card>

        <Card className="bg-slate-900/80 backdrop-blur border-slate-700 mb-8">
          <CardHeader>
            <CardTitle className="text-2xl text-white flex items-center gap-2">
              <Building2 className="h-6 w-6 text-blue-500" />
              Other Involved Agencies
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6 text-slate-300">
            <p className="leading-relaxed">
              Several agencies play critical roles in specific aspects of trade policy and enforcement:
            </p>

            <div className="space-y-6">
              <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6">
                <h3 className="text-xl font-bold text-white mb-3">U.S. Department of Commerce (DOC)</h3>
                <p className="leading-relaxed">
                  The Department of Commerce works to promote job creation, economic growth, and improved living
                  standards. Within the DOC, several agencies handle non-agricultural trade functions, providing
                  comprehensive oversight of commercial trading activities. The DOC develops and implements trade
                  policies that affect how platforms like ours operate in the global marketplace.
                </p>
              </div>

              <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6">
                <h3 className="text-xl font-bold text-white mb-3">International Trade Administration (ITA)</h3>
                <p className="leading-relaxed">
                  As a division of the Department of Commerce, the ITA assists U.S. businesses in the global
                  marketplace. They provide market intelligence, facilitate trade missions, and help resolve trade
                  barriers. The ITA's work ensures that our platform can operate internationally while maintaining
                  compliance with cross-border trading regulations.
                </p>
              </div>

              <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6">
                <h3 className="text-xl font-bold text-white mb-3">U.S. International Trade Commission (USITC)</h3>
                <p className="leading-relaxed">
                  The USITC is an independent federal agency that provides trade expertise to both legislative and
                  executive branches. They determine the economic effect of trade agreements and investigate
                  trade-related issues. Their analyses help shape the regulatory environment in which trading platforms
                  operate, ensuring fair competition and market access.
                </p>
              </div>

              <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6">
                <h3 className="text-xl font-bold text-white mb-3">U.S. Customs and Border Protection (CBP)</h3>
                <p className="leading-relaxed">
                  CBP is responsible for interpreting and enforcing U.S. tariff laws and regulations. While primarily
                  focused on physical goods, their regulations extend to financial transactions crossing borders. Our
                  platform complies with CBP requirements for international fund transfers and cross-border trading
                  activities.
                </p>
              </div>

              <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6">
                <h3 className="text-xl font-bold text-white mb-3">Federal Trade Commission (FTC)</h3>
                <p className="leading-relaxed">
                  The FTC focuses on preventing unfair or deceptive trade practices within the U.S. market, including
                  antitrust enforcement and consumer protection. They ensure that trading platforms maintain
                  transparency, provide accurate information to users, and operate without engaging in deceptive
                  practices. Our compliance with FTC guidelines protects users from fraud and ensures honest trading
                  practices.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <Card className="bg-slate-900/80 backdrop-blur border-slate-700">
            <CardHeader>
              <CardTitle className="text-xl text-white flex items-center gap-2">
                <Shield className="h-5 w-5 text-emerald-500" />
                Primary Authorities
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-slate-300">
              <div className="bg-emerald-950/20 border border-emerald-500/30 rounded p-4">
                <h4 className="font-bold text-emerald-400 mb-2">Trade Remedies Authority (TRA)</h4>
                <p className="text-sm leading-relaxed">
                  The TRA investigates whether new trade measures are needed to prevent injury to UK industries from
                  unfair trading practices and unforeseen surges in imports. We maintain full compliance with TRA
                  regulations governing fair trading practices.
                </p>
              </div>

              <div className="bg-emerald-950/20 border border-emerald-500/30 rounded p-4">
                <h4 className="font-bold text-emerald-400 mb-2">Commodity Futures Trading Commission (CFTC)</h4>
                <p className="text-sm leading-relaxed">
                  The CFTC regulates the U.S. derivatives markets, including futures, swaps, and certain kinds of
                  options. Our commodity trading features comply with CFTC regulations to ensure market integrity.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-900/80 backdrop-blur border-slate-700">
            <CardHeader>
              <CardTitle className="text-xl text-white flex items-center gap-2">
                <Globe className="h-5 w-5 text-blue-500" />
                International Authorities
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-slate-300">
              <div className="bg-blue-950/20 border border-blue-500/30 rounded p-4">
                <h4 className="font-bold text-blue-400 mb-2">European Free Trade Association (EFTA)</h4>
                <p className="text-sm leading-relaxed">
                  EFTA promotes free trade and economic integration between its member states. Our platform's European
                  operations adhere to EFTA guidelines, ensuring seamless trading experiences across member countries.
                </p>
              </div>

              <div className="bg-blue-950/20 border border-blue-500/30 rounded p-4">
                <h4 className="font-bold text-blue-400 mb-2">Financial Conduct Authority (FCA)</h4>
                <p className="text-sm leading-relaxed">
                  The FCA regulates financial firms providing services to consumers in the UK. We maintain compliance
                  with FCA standards for consumer protection, market integrity, and competition.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="bg-slate-900/80 backdrop-blur border-slate-700">
          <CardHeader>
            <CardTitle className="text-2xl text-white">Our Commitment to Compliance</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-slate-300">
            <p className="leading-relaxed">
              We are fully legalized and authorized by these regulatory bodies to provide trading services. Our platform
              undergoes regular audits and compliance reviews to ensure we meet the highest standards of financial
              regulation and consumer protection.
            </p>
            <p className="leading-relaxed">
              This multi-jurisdictional authorization demonstrates our commitment to operating within established legal
              frameworks, protecting our users' interests, and maintaining the integrity of the financial markets. All
              transactions on our platform are monitored and recorded in accordance with international anti-money
              laundering (AML) and know-your-customer (KYC) regulations.
            </p>
            <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6 mt-6">
              <h4 className="font-bold text-white mb-3">Your Rights as a Trader</h4>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start gap-2">
                  <span className="text-emerald-500 mt-1">✓</span>
                  <span>Transparent pricing and fee structures</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-500 mt-1">✓</span>
                  <span>Protection against fraudulent activities</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-500 mt-1">✓</span>
                  <span>Right to withdraw funds at any time</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-500 mt-1">✓</span>
                  <span>Access to dispute resolution mechanisms</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-500 mt-1">✓</span>
                  <span>Data privacy and security protections</span>
                </li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
