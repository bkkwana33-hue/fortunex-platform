"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { fetchCryptoPrices } from "@/lib/crypto-api"

interface CryptoData {
  id: string
  symbol: string
  name: string
  current_price: number
  price_change_percentage_24h: number
}

interface Candlestick {
  time: number
  open: number
  high: number
  low: number
  close: number
  volume: number
}

export default function MarketAnalysisPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [cryptos, setCryptos] = useState<CryptoData[]>([])
  const [selectedCrypto, setSelectedCrypto] = useState<string>("bitcoin")
  const [candlesticks, setCandlesticks] = useState<Candlestick[]>([])
  const [timeframe, setTimeframe] = useState<string>("1H")
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const currentUser = localStorage.getItem("currentUser")
    if (!currentUser) {
      router.push("/login")
      return
    }
    setUser(JSON.parse(currentUser))
    loadCryptos()
  }, [router])

  useEffect(() => {
    if (selectedCrypto) {
      generateCandlestickData()
    }
  }, [selectedCrypto, timeframe])

  const loadCryptos = async () => {
    try {
      const data = await fetchCryptoPrices()
      setCryptos(data)
      setLoading(false)
    } catch (error) {
      console.error("Error loading cryptos:", error)
      setLoading(false)
    }
  }

  const generateCandlestickData = () => {
    const crypto = cryptos.find((c) => c.id === selectedCrypto)
    if (!crypto) return

    const basePrice = crypto.current_price || 50000
    const candles: Candlestick[] = []
    const numCandles = timeframe === "1M" ? 30 : timeframe === "1D" ? 24 : timeframe === "1H" ? 60 : 15

    let currentPrice = basePrice * 0.95 // Start 5% lower to show uptrend
    const now = Date.now()

    for (let i = numCandles; i >= 0; i--) {
      const timeOffset =
        timeframe === "1M"
          ? i * 24 * 60 * 60 * 1000
          : timeframe === "1D"
            ? i * 60 * 60 * 1000
            : timeframe === "1H"
              ? i * 60 * 1000
              : i * 15 * 1000

      const open = currentPrice
      const volatility = basePrice * 0.002 // 0.2% volatility
      const change = (Math.random() - 0.45) * volatility // Slightly bullish bias
      const close = open + change
      const high = Math.max(open, close) * (1 + Math.random() * 0.001)
      const low = Math.min(open, close) * (1 - Math.random() * 0.001)
      const volume = Math.random() * 1000000 + 500000

      candles.push({
        time: now - timeOffset,
        open,
        high,
        low,
        close,
        volume,
      })

      currentPrice = close
    }

    setCandlesticks(candles.reverse())
  }

  const calculateMA = (period: number) => {
    if (candlesticks.length < period) return []

    const ma: { time: number; value: number }[] = []
    for (let i = period - 1; i < candlesticks.length; i++) {
      const sum = candlesticks.slice(i - period + 1, i + 1).reduce((acc, candle) => acc + candle.close, 0)
      ma.push({
        time: candlesticks[i].time,
        value: sum / period,
      })
    }
    return ma
  }

  const ma20 = calculateMA(20)
  const ma50 = calculateMA(50)

  const maxPrice =
    candlesticks.length > 0
      ? Math.max(
          ...candlesticks.map((c) => c.high),
          ...(ma20.length > 0 ? ma20.map((m) => m.value) : []),
          ...(ma50.length > 0 ? ma50.map((m) => m.value) : []),
        )
      : 100

  const minPrice =
    candlesticks.length > 0
      ? Math.min(
          ...candlesticks.map((c) => c.low),
          ...(ma20.length > 0 ? ma20.map((m) => m.value) : []),
          ...(ma50.length > 0 ? ma50.map((m) => m.value) : []),
        )
      : 0

  const priceRange = maxPrice - minPrice || 1
  const chartHeight = 400
  const candleWidth = Math.max(2, 600 / (candlesticks.length || 1) - 2)

  const priceToY = (price: number) => {
    return chartHeight - ((price - minPrice) / priceRange) * chartHeight
  }

  if (!user || loading) {
    return null
  }

  const selectedCryptoData = cryptos.find((c) => c.id === selectedCrypto)

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Header */}
      <header className="bg-slate-900 border-b border-slate-700 p-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button onClick={() => router.push("/dashboard")} variant="ghost" className="text-slate-300">
              ← Back to Dashboard
            </Button>
            <h1 className="text-2xl font-bold text-emerald-500">Market Analysis Center</h1>
          </div>
          <div className="text-right">
            <p className="font-semibold text-white">{user.fullName}</p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto p-8">
        <div className="space-y-6">
          {/* Controls */}
          <Card className="bg-slate-900 border-slate-700 p-6">
            <div className="flex items-center gap-6">
              <div className="flex-1">
                <label className="text-sm text-slate-400 mb-2 block">Select Asset</label>
                <Select value={selectedCrypto} onValueChange={setSelectedCrypto}>
                  <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    {cryptos.map((crypto) => (
                      <SelectItem key={crypto.id} value={crypto.id} className="text-white">
                        {crypto.name} ({crypto.symbol?.toUpperCase()})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm text-slate-400 mb-2 block">Timeframe</label>
                <div className="flex gap-2">
                  {["15M", "1H", "1D", "1M"].map((tf) => (
                    <Button
                      key={tf}
                      onClick={() => setTimeframe(tf)}
                      variant={timeframe === tf ? "default" : "outline"}
                      className={
                        timeframe === tf
                          ? "bg-emerald-600 hover:bg-emerald-700"
                          : "border-slate-700 text-slate-300 hover:bg-slate-800"
                      }
                    >
                      {tf}
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          </Card>

          {/* Price Info */}
          {selectedCryptoData && (
            <Card className="bg-slate-900 border-slate-700 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-3xl font-bold text-white">
                    $
                    {(selectedCryptoData.current_price || 0).toLocaleString(undefined, {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2,
                    })}
                  </h2>
                  <p className="text-sm text-slate-400 mt-1">{selectedCryptoData.name}</p>
                </div>
                <div
                  className={`text-right ${(selectedCryptoData.price_change_percentage_24h || 0) >= 0 ? "text-emerald-500" : "text-red-500"}`}
                >
                  <p className="text-2xl font-bold">
                    {(selectedCryptoData.price_change_percentage_24h || 0) >= 0 ? "+" : ""}
                    {(selectedCryptoData.price_change_percentage_24h || 0).toFixed(2)}%
                  </p>
                  <p className="text-sm">24h Change</p>
                </div>
              </div>
            </Card>
          )}

          {/* Candlestick Chart */}
          <Card className="bg-slate-900 border-slate-700 p-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold text-white">K-Line Chart with Indicators</h3>
                <div className="flex gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-0.5 bg-blue-500"></div>
                    <span className="text-slate-400">MA20</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-0.5 bg-purple-500"></div>
                    <span className="text-slate-400">MA50</span>
                  </div>
                </div>
              </div>

              <div className="relative bg-slate-950 rounded-lg p-4" style={{ height: chartHeight + 100 }}>
                <svg width="100%" height={chartHeight + 80} className="overflow-visible">
                  {/* Grid Lines */}
                  {[0, 1, 2, 3, 4].map((i) => {
                    const y = (chartHeight / 4) * i
                    const price = maxPrice - (priceRange / 4) * i
                    return (
                      <g key={`grid-${i}`}>
                        <line x1="40" y1={y} x2="100%" y2={y} stroke="#334155" strokeWidth="1" strokeDasharray="4" />
                        <text x="5" y={y + 4} fill="#94a3b8" fontSize="12">
                          ${price.toFixed(2)}
                        </text>
                      </g>
                    )
                  })}

                  {/* Candlesticks */}
                  {candlesticks.map((candle, index) => {
                    const x = 50 + index * (candleWidth + 2)
                    const isGreen = candle.close >= candle.open
                    const bodyTop = priceToY(Math.max(candle.open, candle.close))
                    const bodyBottom = priceToY(Math.min(candle.open, candle.close))
                    const bodyHeight = Math.max(1, bodyBottom - bodyTop)

                    return (
                      <g key={index}>
                        {/* Wick */}
                        <line
                          x1={x + candleWidth / 2}
                          y1={priceToY(candle.high)}
                          x2={x + candleWidth / 2}
                          y2={priceToY(candle.low)}
                          stroke={isGreen ? "#10b981" : "#ef4444"}
                          strokeWidth="1"
                        />
                        {/* Body */}
                        <rect
                          x={x}
                          y={bodyTop}
                          width={candleWidth}
                          height={bodyHeight}
                          fill={isGreen ? "#10b981" : "#ef4444"}
                        />
                      </g>
                    )
                  })}

                  {/* MA20 Line */}
                  {ma20.length > 1 && (
                    <polyline
                      points={ma20
                        .map((point, index) => {
                          const x = 50 + (index + 19) * (candleWidth + 2) + candleWidth / 2
                          const y = priceToY(point.value)
                          return `${x},${y}`
                        })
                        .join(" ")}
                      fill="none"
                      stroke="#3b82f6"
                      strokeWidth="2"
                    />
                  )}

                  {/* MA50 Line */}
                  {ma50.length > 1 && (
                    <polyline
                      points={ma50
                        .map((point, index) => {
                          const x = 50 + (index + 49) * (candleWidth + 2) + candleWidth / 2
                          const y = priceToY(point.value)
                          return `${x},${y}`
                        })
                        .join(" ")}
                      fill="none"
                      stroke="#a855f7"
                      strokeWidth="2"
                    />
                  )}

                  {/* Volume bars */}
                  {candlesticks.map((candle, index) => {
                    const x = 50 + index * (candleWidth + 2)
                    const maxVolume = Math.max(...candlesticks.map((c) => c.volume))
                    const volumeHeight = (candle.volume / maxVolume) * 60
                    const isGreen = candle.close >= candle.open

                    return (
                      <rect
                        key={`volume-${index}`}
                        x={x}
                        y={chartHeight + 20 + (60 - volumeHeight)}
                        width={candleWidth}
                        height={volumeHeight}
                        fill={isGreen ? "#10b98150" : "#ef444450"}
                      />
                    )
                  })}

                  <text x="5" y={chartHeight + 50} fill="#94a3b8" fontSize="12">
                    Volume
                  </text>
                </svg>
              </div>

              <div className="grid grid-cols-3 gap-4 text-sm">
                <div className="bg-slate-800/50 p-3 rounded">
                  <p className="text-slate-400">Open</p>
                  <p className="text-white font-bold">
                    ${(candlesticks[candlesticks.length - 1]?.open || 0).toFixed(2)}
                  </p>
                </div>
                <div className="bg-slate-800/50 p-3 rounded">
                  <p className="text-slate-400">High</p>
                  <p className="text-emerald-500 font-bold">
                    ${(candlesticks[candlesticks.length - 1]?.high || 0).toFixed(2)}
                  </p>
                </div>
                <div className="bg-slate-800/50 p-3 rounded">
                  <p className="text-slate-400">Low</p>
                  <p className="text-red-500 font-bold">
                    ${(candlesticks[candlesticks.length - 1]?.low || 0).toFixed(2)}
                  </p>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}
