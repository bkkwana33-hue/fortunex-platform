"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { formatLargeNumber } from "@/lib/crypto-api"

interface CryptoData {
  id: string
  symbol: string
  name: string
  current_price: number
  price_change_percentage_24h: number
  market_cap: number
  total_volume: number
  high_24h: number
  low_24h: number
}

export default function MarketReviewPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [cryptos, setCryptos] = useState<CryptoData[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const currentUser = localStorage.getItem("currentUser")
    if (!currentUser) {
      router.push("/login")
      return
    }
    setUser(JSON.parse(currentUser))

    loadCryptos()
    const interval = setInterval(loadCryptos, 10000) // Update every 10 seconds
    return () => clearInterval(interval)
  }, [router])

  const loadCryptos = async () => {
    try {
      const response = await fetch("/api/top-cryptos")
      const data = await response.json()
      setCryptos(data)
      setLoading(false)
    } catch (error) {
      console.error("Error loading cryptos:", error)
      setLoading(false)
    }
  }

  if (!user) {
    return null
  }

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Header */}
      <header className="bg-slate-900 border-b border-slate-700 p-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <h1 className="text-2xl font-bold text-amber-500">Market Review - Top 30 Cryptocurrencies</h1>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="text-sm text-slate-400">Balance</p>
              <p className="font-bold text-amber-500">${user.balance?.toLocaleString() || "10,000"}</p>
            </div>
            <Button onClick={() => router.push("/dashboard")} variant="outline">
              Back to Dashboard
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto p-8">
        <div className="mb-6">
          <p className="text-slate-400">Real-time cryptocurrency market data with prices, market cap, and 24h volume</p>
        </div>

        {loading ? (
          <div className="grid gap-3">
            {[...Array(30)].map((_, i) => (
              <Card key={i} className="bg-slate-900 border-slate-700 animate-pulse">
                <CardContent className="p-4">
                  <div className="h-16 bg-slate-800 rounded" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="space-y-2">
            {/* Header Row */}
            <div className="grid grid-cols-7 gap-4 px-6 py-3 bg-slate-900 rounded-lg text-slate-400 text-sm font-semibold">
              <div>Rank</div>
              <div className="col-span-2">Name</div>
              <div className="text-right">Price</div>
              <div className="text-right">24h Change</div>
              <div className="text-right">Market Cap</div>
              <div className="text-right">24h Volume</div>
            </div>

            {/* Data Rows */}
            {cryptos.map((crypto, index) => (
              <Card
                key={crypto.id}
                className="bg-slate-900 border-slate-700 hover:bg-slate-800 transition-all cursor-pointer"
              >
                <CardContent className="p-4">
                  <div className="grid grid-cols-7 gap-4 items-center">
                    {/* Rank */}
                    <div className="text-slate-400 font-semibold">{index + 1}</div>

                    {/* Name & Symbol */}
                    <div className="col-span-2 flex items-center gap-3">
                      <div className="w-10 h-10 bg-amber-600/20 rounded-full flex items-center justify-center">
                        <span className="text-sm font-bold text-amber-500">{crypto.symbol.toUpperCase()}</span>
                      </div>
                      <div>
                        <h3 className="font-bold text-white">{crypto.name}</h3>
                        <p className="text-xs text-slate-400">{crypto.symbol.toUpperCase()}</p>
                      </div>
                    </div>

                    {/* Price */}
                    <div className="text-right">
                      <p className="font-bold text-white">
                        ${crypto.current_price >= 1 ? crypto.current_price.toFixed(2) : crypto.current_price.toFixed(6)}
                      </p>
                    </div>

                    {/* 24h Change */}
                    <div className="text-right">
                      <p
                        className={`font-semibold ${
                          crypto.price_change_percentage_24h >= 0 ? "text-emerald-500" : "text-red-500"
                        }`}
                      >
                        {crypto.price_change_percentage_24h >= 0 ? "↑" : "↓"}{" "}
                        {Math.abs(crypto.price_change_percentage_24h).toFixed(2)}%
                      </p>
                    </div>

                    {/* Market Cap */}
                    <div className="text-right">
                      <p className="text-white font-semibold">{formatLargeNumber(crypto.market_cap)}</p>
                    </div>

                    {/* 24h Volume */}
                    <div className="text-right">
                      <p className="text-slate-400">{formatLargeNumber(crypto.total_volume)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
