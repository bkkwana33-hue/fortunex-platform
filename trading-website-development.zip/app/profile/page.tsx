"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import Image from "next/image"

const CRYPTO_NETWORKS = {
  "USDT (Tether)": [
    { name: "TRON (TRC20)", code: "TRC20", address: "TDCMuswN6VhVwGJctxnQDuELxHkUQZ2rkQ" },
    { name: "Ethereum (ERC20)", code: "ERC20", address: "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb" },
    { name: "BNB Chain (BEP20)", code: "BEP20", address: "0x55d398326f99059fF775485246999027B3197955" },
  ],
  "BTC (Bitcoin)": [{ name: "Bitcoin Network", code: "BTC", address: "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh" }],
  "ETH (Ethereum)": [
    { name: "Ethereum Network", code: "ETH", address: "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb" },
    { name: "BNB Chain (BEP20)", code: "BEP20", address: "0x2170Ed0880ac9A755fd29B2688956BD959F933F8" },
  ],
  "XRP (Ripple)": [{ name: "XRP Ledger", code: "XRP", address: "rLHzPsX6oXkzU9r9KhB7sVH9vJmYTp7kBn" }],
  "SOL (Solana)": [{ name: "Solana Network", code: "SOL", address: "7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU" }],
  "ADA (Cardano)": [
    { name: "Cardano Network", code: "ADA", address: "addr1qxqs59lph5qvfmwtjjgkfqgz7h0k34f9jcuqkjl4m3qnj7cvt0k" },
  ],
  "GOLD (COMEX Gold)": [{ name: "COMEX Network", code: "GOLD", address: "GOLD1234567890ABCDEF" }],
}

export default function ProfilePage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [tradeHistory, setTradeHistory] = useState<any[]>([])
  const [transactions, setTransactions] = useState<any[]>([])
  const [selectedCrypto, setSelectedCrypto] = useState<string>("USDT (Tether)")
  const [selectedNetwork, setSelectedNetwork] = useState<any>(null)
  const [depositAmount, setDepositAmount] = useState("")
  const [withdrawAmount, setWithdrawAmount] = useState("")
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")
  const [selectedTrade, setSelectedTrade] = useState<any>(null)

  useEffect(() => {
    const currentUser = localStorage.getItem("currentUser")
    if (!currentUser) {
      router.push("/login")
      return
    }
    setUser(JSON.parse(currentUser))
    loadHistory()
  }, [router])

  const loadHistory = () => {
    const historyData = localStorage.getItem("tradeHistory") || "[]"
    const allHistory = JSON.parse(historyData)

    const transactionsData = localStorage.getItem("transactions") || "[]"
    const allTransactions = JSON.parse(transactionsData)

    const sortedHistory = allHistory.sort((a: any, b: any) => {
      const timeA = new Date(b.completedTime || b.timestamp || 0).getTime()
      const timeB = new Date(a.completedTime || a.timestamp || 0).getTime()
      return timeA - timeB
    })

    setTradeHistory(sortedHistory)
    setTransactions(allTransactions)
  }

  const handleDeposit = () => {
    setError("")
    setSuccess("")

    if (!selectedNetwork) {
      setError("Please select a network")
      return
    }

    const amount = Number.parseFloat(depositAmount)
    if (!amount || amount <= 0) {
      setError("Please enter a valid amount")
      return
    }

    // Update user balance
    const updatedUser = { ...user, balance: user.balance + amount }
    localStorage.setItem("currentUser", JSON.stringify(updatedUser))

    // Update users array
    const usersData = localStorage.getItem("users") || "[]"
    const users = JSON.parse(usersData)
    const userIndex = users.findIndex((u: any) => u.email === user.email)
    if (userIndex !== -1) {
      users[userIndex] = updatedUser
      localStorage.setItem("users", JSON.stringify(users))
    }

    // Record transaction
    const transaction = {
      id: Date.now(),
      type: "deposit",
      amount,
      crypto: selectedCrypto,
      network: selectedNetwork.name,
      date: new Date().toISOString(),
      status: "completed",
    }

    const transactionsData = localStorage.getItem("transactions") || "[]"
    const allTransactions = JSON.parse(transactionsData)
    allTransactions.push(transaction)
    localStorage.setItem("transactions", JSON.stringify(allTransactions))

    setUser(updatedUser)
    setDepositAmount("")
    setSuccess(`Successfully deposited $${amount.toLocaleString()} via ${selectedCrypto} (${selectedNetwork.code})`)
    loadHistory()
  }

  const handleWithdraw = () => {
    setError("")
    setSuccess("")

    if (!selectedNetwork) {
      setError("Please select a network")
      return
    }

    const amount = Number.parseFloat(withdrawAmount)
    if (!amount || amount <= 0) {
      setError("Please enter a valid amount")
      return
    }

    if (amount > user.balance) {
      setError("Insufficient balance")
      return
    }

    // Update user balance
    const updatedUser = { ...user, balance: user.balance - amount }
    localStorage.setItem("currentUser", JSON.stringify(updatedUser))

    // Update users array
    const usersData = localStorage.getItem("users") || "[]"
    const users = JSON.parse(usersData)
    const userIndex = users.findIndex((u: any) => u.email === user.email)
    if (userIndex !== -1) {
      users[userIndex] = updatedUser
      localStorage.setItem("users", JSON.stringify(users))
    }

    // Record transaction
    const transaction = {
      id: Date.now(),
      type: "withdraw",
      amount,
      crypto: selectedCrypto,
      network: selectedNetwork.name,
      date: new Date().toISOString(),
      status: "completed",
    }

    const transactionsData = localStorage.getItem("transactions") || "[]"
    const allTransactions = JSON.parse(transactionsData)
    allTransactions.push(transaction)
    localStorage.setItem("transactions", JSON.stringify(allTransactions))

    setUser(updatedUser)
    setWithdrawAmount("")
    setSuccess(`Successfully withdrew $${amount.toLocaleString()} via ${selectedCrypto} (${selectedNetwork.code})`)
    loadHistory()
  }

  if (!user) return null

  const totalProfit = tradeHistory.reduce((sum, trade) => sum + (Number.parseFloat(trade.profit) || 0), 0)
  const totalTrades = tradeHistory.length
  const winRate = 100 // Always profitable

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <header className="bg-slate-900/80 backdrop-blur-sm border-b border-slate-700 p-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              onClick={() => router.push("/dashboard")}
              variant="ghost"
              className="text-slate-400 hover:text-white"
            >
              ← Dashboard
            </Button>
            <h1 className="text-2xl font-bold text-white">Profile</h1>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto p-8">
        {/* Profile Info Card */}
        <Card className="bg-slate-900/80 backdrop-blur border-slate-700 p-6 mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold text-white mb-2">{user.fullName}</h2>
              <p className="text-slate-400">{user.email}</p>
              <p className="text-slate-400">{user.phone}</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-slate-400 mb-1">Current Balance</p>
              <p className="text-4xl font-bold text-amber-500">
                ${user.balance?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4 mt-6 pt-6 border-t border-slate-700">
            <div className="text-center">
              <p className="text-2xl font-bold text-emerald-500">
                ${totalProfit.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </p>
              <p className="text-sm text-slate-400">Total Profit</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-white">{totalTrades}</p>
              <p className="text-sm text-slate-400">Total Trades</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-emerald-500">{winRate}%</p>
              <p className="text-sm text-slate-400">Win Rate</p>
            </div>
          </div>
        </Card>

        {/* Tabs for different sections */}
        <Tabs defaultValue="history" className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-slate-900/80 border border-slate-700">
            <TabsTrigger value="history">Trade History</TabsTrigger>
            <TabsTrigger value="deposit">Deposit</TabsTrigger>
            <TabsTrigger value="withdraw">Withdraw</TabsTrigger>
            <TabsTrigger value="transactions">Transactions</TabsTrigger>
          </TabsList>

          {/* Trade History */}
          <TabsContent value="history" className="mt-6">
            {tradeHistory.length === 0 ? (
              <Card className="bg-slate-900/80 backdrop-blur border-slate-700 p-12 text-center">
                <p className="text-slate-400">No trade history yet</p>
              </Card>
            ) : (
              <div className="space-y-4">
                {tradeHistory.map((trade) => {
                  const profitValue = Number.parseFloat(trade.profit)
                  const profitPercent = Number.parseFloat(trade.profitPercent)
                  const isProfitable = profitValue >= 0

                  return (
                    <Card key={trade.id} className="bg-slate-900/80 backdrop-blur border-slate-700 p-6">
                      <div className="flex items-center justify-between gap-4">
                        <div className="flex-1">
                          <h3 className="text-xl font-bold text-white">{trade.name || trade.symbol}</h3>
                          <p
                            className={`text-sm font-semibold ${trade.type === "long" ? "text-emerald-500" : "text-red-500"}`}
                          >
                            {trade.type === "long" ? "Buy Long ↑" : "Sell Short ↓"}
                          </p>
                          <p className="text-sm text-slate-400 mt-1">
                            {new Date(trade.completedTime).toLocaleString()}
                          </p>
                        </div>
                        <div className="text-center">
                          <p className="text-sm text-slate-400">Trade Amount</p>
                          <p className="text-xl font-bold text-white">
                            $
                            {Number.parseFloat(trade.amount).toLocaleString(undefined, {
                              minimumFractionDigits: 2,
                              maximumFractionDigits: 2,
                            })}
                          </p>
                          <p className="text-xs text-slate-500">{trade.timeframeLabel}</p>
                        </div>
                        <div className="text-center">
                          <p className="text-sm text-slate-400">{isProfitable ? "Profit" : "Loss"}</p>
                          <p className={`text-2xl font-bold ${isProfitable ? "text-emerald-500" : "text-red-500"}`}>
                            {isProfitable ? "+" : "-"}$
                            {Math.abs(profitValue).toLocaleString(undefined, {
                              minimumFractionDigits: 2,
                              maximumFractionDigits: 2,
                            })}
                          </p>
                          <p className={`text-sm ${isProfitable ? "text-emerald-400" : "text-red-400"}`}>
                            {isProfitable ? "+" : ""}
                            {profitPercent}%
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-slate-400">Total Return</p>
                          <p className="text-xl font-bold text-white">
                            $
                            {Number.parseFloat(trade.totalReturn).toLocaleString(undefined, {
                              minimumFractionDigits: 2,
                              maximumFractionDigits: 2,
                            })}
                          </p>
                        </div>
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                              variant="outline"
                              className="border-slate-600 hover:border-amber-500 hover:bg-amber-950/20 bg-transparent"
                              onClick={() => setSelectedTrade(trade)}
                            >
                              Details
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="bg-slate-900 border-slate-700 text-white max-w-2xl">
                            <DialogHeader>
                              <DialogTitle className="text-2xl font-bold text-amber-500">
                                {selectedTrade?.name || selectedTrade?.symbol} - Trade Details
                              </DialogTitle>
                              <DialogDescription className="text-slate-400">
                                Complete information about your trade
                              </DialogDescription>
                            </DialogHeader>
                            {selectedTrade && (
                              <div className="space-y-6 mt-4">
                                <div className="grid grid-cols-2 gap-4 p-4 bg-slate-800/50 rounded-lg">
                                  <div>
                                    <p className="text-sm text-slate-400">Asset</p>
                                    <p className="text-xl font-bold text-white">
                                      {selectedTrade.name || selectedTrade.symbol}
                                    </p>
                                  </div>
                                  <div>
                                    <p className="text-sm text-slate-400">Trade Type</p>
                                    <p
                                      className={`text-xl font-bold ${selectedTrade.type === "long" ? "text-emerald-500" : "text-red-500"}`}
                                    >
                                      {selectedTrade.type === "long" ? "Buy Long ↑" : "Sell Short ↓"}
                                    </p>
                                  </div>
                                </div>

                                <div className="p-4 bg-slate-800/50 rounded-lg">
                                  <h3 className="text-lg font-bold text-white mb-3">Time Information</h3>
                                  <div className="grid grid-cols-3 gap-4">
                                    <div>
                                      <p className="text-sm text-slate-400">Started</p>
                                      <p className="text-sm font-semibold text-white">
                                        {new Date(selectedTrade.startTime).toLocaleString()}
                                      </p>
                                    </div>
                                    <div>
                                      <p className="text-sm text-slate-400">Completed</p>
                                      <p className="text-sm font-semibold text-white">
                                        {new Date(selectedTrade.completedTime).toLocaleString()}
                                      </p>
                                    </div>
                                    <div>
                                      <p className="text-sm text-slate-400">Duration</p>
                                      <p className="text-sm font-semibold text-amber-500">
                                        {selectedTrade.timeframeLabel}
                                      </p>
                                    </div>
                                  </div>
                                </div>

                                <div className="p-4 bg-slate-800/50 rounded-lg">
                                  <h3 className="text-lg font-bold text-white mb-3">Price Movement</h3>
                                  <div className="grid grid-cols-3 gap-4">
                                    <div>
                                      <p className="text-sm text-slate-400">Entry Price</p>
                                      <p className="text-lg font-bold text-white">
                                        $
                                        {selectedTrade.entryPrice?.toLocaleString(undefined, {
                                          minimumFractionDigits: 2,
                                          maximumFractionDigits: 2,
                                        })}
                                      </p>
                                    </div>
                                    <div>
                                      <p className="text-sm text-slate-400">
                                        Exit Price {selectedTrade.profit > 0 ? "(Profit Adjusted)" : ""}
                                      </p>
                                      <p
                                        className={`text-lg font-bold ${selectedTrade.profit >= 0 ? "text-emerald-500" : "text-red-500"}`}
                                      >
                                        $
                                        {selectedTrade.exitPrice?.toLocaleString(undefined, {
                                          minimumFractionDigits: 2,
                                          maximumFractionDigits: 2,
                                        })}
                                      </p>
                                      {selectedTrade.profit > 0 && (
                                        <p className="text-xs text-slate-500">+$10-20 profit guarantee</p>
                                      )}
                                    </div>
                                    <div>
                                      <p className="text-sm text-slate-400">Price Change</p>
                                      <p
                                        className={`text-lg font-bold ${selectedTrade.profit >= 0 ? "text-emerald-500" : "text-red-500"}`}
                                      >
                                        {selectedTrade.profit >= 0 ? "+" : ""}
                                        {(
                                          ((selectedTrade.exitPrice - selectedTrade.entryPrice) /
                                            selectedTrade.entryPrice) *
                                          100
                                        ).toFixed(2)}
                                        %
                                      </p>
                                    </div>
                                  </div>
                                </div>

                                <div
                                  className={`p-4 ${selectedTrade.profit >= 0 ? "bg-gradient-to-br from-emerald-950/30 to-amber-950/30 border border-emerald-500/30" : "bg-gradient-to-br from-red-950/30 to-red-900/30 border border-red-500/30"} rounded-lg`}
                                >
                                  <h3 className="text-lg font-bold text-white mb-3">Financial Summary</h3>
                                  <div className="space-y-3">
                                    <div className="flex justify-between">
                                      <p className="text-slate-400">Trade Amount</p>
                                      <p className="text-lg font-bold text-white">
                                        $
                                        {Number.parseFloat(selectedTrade.amount).toLocaleString(undefined, {
                                          minimumFractionDigits: 2,
                                          maximumFractionDigits: 2,
                                        })}
                                      </p>
                                    </div>
                                    <div className="flex justify-between">
                                      <p className="text-slate-400">{selectedTrade.profit >= 0 ? "Profit" : "Loss"}</p>
                                      <p
                                        className={`text-lg font-bold ${selectedTrade.profit >= 0 ? "text-emerald-500" : "text-red-500"}`}
                                      >
                                        {selectedTrade.profit >= 0 ? "+" : "-"}$
                                        {Math.abs(Number.parseFloat(selectedTrade.profit)).toLocaleString(undefined, {
                                          minimumFractionDigits: 2,
                                          maximumFractionDigits: 2,
                                        })}{" "}
                                        ({selectedTrade.profit >= 0 ? "+" : "-"}
                                        {Math.abs(Number.parseFloat(selectedTrade.profitPercent))}%)
                                      </p>
                                    </div>
                                    <div className="flex justify-between pt-3 border-t border-slate-700">
                                      <p className="text-white font-semibold">Total Return</p>
                                      <p className="text-2xl font-bold text-amber-500">
                                        $
                                        {Number.parseFloat(selectedTrade.totalReturn).toLocaleString(undefined, {
                                          minimumFractionDigits: 2,
                                          maximumFractionDigits: 2,
                                        })}
                                      </p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            )}
                          </DialogContent>
                        </Dialog>
                      </div>
                    </Card>
                  )
                })}
              </div>
            )}
          </TabsContent>

          <TabsContent value="deposit" className="mt-6">
            <Card className="bg-slate-900/80 backdrop-blur border-slate-700 p-6">
              <h3 className="text-xl font-bold text-white mb-6">Deposit Funds</h3>

              {error && (
                <div className="mb-4 p-3 bg-red-900/30 border border-red-500 rounded text-red-300 text-sm">{error}</div>
              )}
              {success && (
                <div className="mb-4 p-3 bg-emerald-900/30 border border-emerald-500 rounded text-emerald-300 text-sm">
                  {success}
                </div>
              )}

              <div className="space-y-4">
                <div>
                  <label className="text-sm text-slate-400 mb-2 block">Select Cryptocurrency</label>
                  <Select
                    value={selectedCrypto}
                    onValueChange={(value) => {
                      setSelectedCrypto(value)
                      setSelectedNetwork(null)
                    }}
                  >
                    <SelectTrigger className="bg-slate-800 border-slate-700">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-slate-700">
                      {Object.keys(CRYPTO_NETWORKS).map((crypto) => (
                        <SelectItem key={crypto} value={crypto}>
                          {crypto}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm text-slate-400 mb-2 block">Select Network</label>
                  <Select
                    value={selectedNetwork?.code || ""}
                    onValueChange={(value) => {
                      const network = CRYPTO_NETWORKS[selectedCrypto as keyof typeof CRYPTO_NETWORKS].find(
                        (n) => n.code === value,
                      )
                      setSelectedNetwork(network)
                    }}
                  >
                    <SelectTrigger className="bg-slate-800 border-slate-700">
                      <SelectValue placeholder="Choose network" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-slate-700">
                      {CRYPTO_NETWORKS[selectedCrypto as keyof typeof CRYPTO_NETWORKS]?.map((network) => (
                        <SelectItem key={network.code} value={network.code}>
                          {network.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {selectedNetwork && (
                  <>
                    <div className="p-4 bg-slate-800/50 rounded-lg">
                      <p className="text-sm text-slate-400 mb-2">Deposit Address ({selectedNetwork.code})</p>
                      <p className="text-white font-mono text-sm break-all">{selectedNetwork.address}</p>
                      {selectedCrypto === "USDT (Tether)" && selectedNetwork.code === "TRC20" && (
                        <div className="mt-4 flex justify-center">
                          <div className="bg-white p-4 rounded-lg">
                            <Image
                              src="/images/qq.jpeg"
                              alt="USDT TRC20 QR Code"
                              width={200}
                              height={200}
                              className="rounded"
                            />
                          </div>
                        </div>
                      )}
                    </div>

                    <div>
                      <label className="text-sm text-slate-400 mb-2 block">Amount (USD)</label>
                      <Input
                        type="number"
                        placeholder="Enter amount"
                        value={depositAmount}
                        onChange={(e) => setDepositAmount(e.target.value)}
                        className="bg-slate-800 border-slate-700"
                      />
                    </div>

                    <Button onClick={handleDeposit} className="w-full bg-emerald-600 hover:bg-emerald-700">
                      Confirm Deposit
                    </Button>
                  </>
                )}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="withdraw" className="mt-6">
            <Card className="bg-slate-900/80 backdrop-blur border-slate-700 p-6">
              <h3 className="text-xl font-bold text-white mb-6">Withdraw Funds</h3>

              {error && (
                <div className="mb-4 p-3 bg-red-900/30 border border-red-500 rounded text-red-300 text-sm">{error}</div>
              )}
              {success && (
                <div className="mb-4 p-3 bg-emerald-900/30 border border-emerald-500 rounded text-emerald-300 text-sm">
                  {success}
                </div>
              )}

              <div className="space-y-4">
                <div>
                  <label className="text-sm text-slate-400 mb-2 block">Select Cryptocurrency</label>
                  <Select
                    value={selectedCrypto}
                    onValueChange={(value) => {
                      setSelectedCrypto(value)
                      setSelectedNetwork(null)
                    }}
                  >
                    <SelectTrigger className="bg-slate-800 border-slate-700">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-slate-700">
                      {Object.keys(CRYPTO_NETWORKS).map((crypto) => (
                        <SelectItem key={crypto} value={crypto}>
                          {crypto}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm text-slate-400 mb-2 block">Select Network</label>
                  <Select
                    value={selectedNetwork?.code || ""}
                    onValueChange={(value) => {
                      const network = CRYPTO_NETWORKS[selectedCrypto as keyof typeof CRYPTO_NETWORKS].find(
                        (n) => n.code === value,
                      )
                      setSelectedNetwork(network)
                    }}
                  >
                    <SelectTrigger className="bg-slate-800 border-slate-700">
                      <SelectValue placeholder="Choose network" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-slate-700">
                      {CRYPTO_NETWORKS[selectedCrypto as keyof typeof CRYPTO_NETWORKS]?.map((network) => (
                        <SelectItem key={network.code} value={network.code}>
                          {network.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {selectedNetwork && (
                  <>
                    <div>
                      <label className="text-sm text-slate-400 mb-2 block">Amount (USD)</label>
                      <Input
                        type="number"
                        placeholder="Enter amount"
                        value={withdrawAmount}
                        onChange={(e) => setWithdrawAmount(e.target.value)}
                        className="bg-slate-800 border-slate-700"
                      />
                      <p className="text-xs text-slate-500 mt-1">
                        Available balance: $
                        {user.balance?.toLocaleString(undefined, {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        })}
                      </p>
                    </div>

                    <Button onClick={handleWithdraw} className="w-full bg-amber-600 hover:bg-amber-700">
                      Confirm Withdrawal
                    </Button>
                  </>
                )}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="transactions" className="mt-6">
            {transactions.length === 0 ? (
              <Card className="bg-slate-900/80 backdrop-blur border-slate-700 p-12 text-center">
                <p className="text-slate-400">No transactions yet</p>
              </Card>
            ) : (
              <div className="space-y-4">
                {transactions.reverse().map((txn) => (
                  <Card key={txn.id} className="bg-slate-900/80 backdrop-blur border-slate-700 p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p
                          className={`text-lg font-bold ${txn.type === "deposit" ? "text-emerald-500" : "text-amber-500"}`}
                        >
                          {txn.type === "deposit" ? "Deposit" : "Withdrawal"}
                        </p>
                        <p className="text-sm text-slate-400">
                          {txn.crypto} via {txn.network}
                        </p>
                        <p className="text-xs text-slate-500 mt-1">{new Date(txn.date).toLocaleString()}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold text-white">
                          $
                          {txn.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </p>
                        <p className="text-sm text-emerald-400">{txn.status}</p>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
