"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { useToast } from "@/hooks/use-toast"

export default function ReferFriendsPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [user, setUser] = useState<any>(null)
  const [referralCode, setReferralCode] = useState("")
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    const currentUser = localStorage.getItem("currentUser")
    if (!currentUser) {
      router.push("/login")
      return
    }
    const userData = JSON.parse(currentUser)
    setUser(userData)

    // Generate referral code from user email
    const code = `REF${userData.email.substring(0, 4).toUpperCase()}${Math.random().toString(36).substring(2, 8).toUpperCase()}`
    setReferralCode(code)
  }, [router])

  const copyToClipboard = () => {
    navigator.clipboard.writeText(referralCode)
    setCopied(true)
    toast({
      title: "Copied!",
      description: "Referral code copied to clipboard",
    })
    setTimeout(() => setCopied(false), 2000)
  }

  if (!user) {
    return null
  }

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Header */}
      <header className="bg-slate-900 border-b border-slate-700 p-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button onClick={() => router.push("/dashboard")} variant="ghost" className="text-slate-300">
              ← Back to Dashboard
            </Button>
            <h1 className="text-2xl font-bold text-pink-500">Refer Friends</h1>
          </div>
          <div className="text-right">
            <p className="font-semibold text-white">{user.fullName}</p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto p-8">
        <div className="space-y-6">
          {/* Hero Card */}
          <Card className="bg-gradient-to-br from-pink-950/50 to-slate-900 border-pink-500/30 p-8 text-center">
            <div className="w-20 h-20 mx-auto bg-pink-600/20 rounded-full flex items-center justify-center mb-4">
              <svg className="w-10 h-10 text-pink-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"
                />
              </svg>
            </div>
            <h2 className="text-3xl font-bold text-white mb-4">Invite Friends & Earn Rewards</h2>
            <p className="text-slate-300 text-lg">
              Share your referral code and earn $50 for each friend who joins and trades!
            </p>
          </Card>

          {/* Referral Code */}
          <Card className="bg-slate-900 border-slate-700 p-8">
            <h3 className="text-xl font-bold text-white mb-4">Your Referral Code</h3>
            <div className="flex gap-2">
              <Input
                value={referralCode}
                readOnly
                className="bg-slate-800 border-slate-700 text-white text-xl font-mono text-center"
              />
              <Button onClick={copyToClipboard} className="bg-pink-600 hover:bg-pink-700 text-white px-8">
                {copied ? "Copied!" : "Copy"}
              </Button>
            </div>
          </Card>

          {/* How It Works */}
          <Card className="bg-slate-900 border-slate-700 p-8">
            <h3 className="text-xl font-bold text-white mb-6">How It Works</h3>
            <div className="space-y-6">
              <div className="flex gap-4">
                <div className="w-12 h-12 bg-pink-600/20 rounded-full flex items-center justify-center flex-shrink-0 text-pink-500 font-bold text-xl">
                  1
                </div>
                <div>
                  <h4 className="text-lg font-bold text-white mb-2">Share Your Code</h4>
                  <p className="text-slate-400">
                    Send your unique referral code to friends via email, social media, or messaging apps
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-12 h-12 bg-pink-600/20 rounded-full flex items-center justify-center flex-shrink-0 text-pink-500 font-bold text-xl">
                  2
                </div>
                <div>
                  <h4 className="text-lg font-bold text-white mb-2">Friend Signs Up</h4>
                  <p className="text-slate-400">
                    Your friend creates an account using your referral code and completes verification
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-12 h-12 bg-pink-600/20 rounded-full flex items-center justify-center flex-shrink-0 text-pink-500 font-bold text-xl">
                  3
                </div>
                <div>
                  <h4 className="text-lg font-bold text-white mb-2">They Start Trading</h4>
                  <p className="text-slate-400">
                    When your friend makes their first trade of $500 or more, you both earn rewards
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-12 h-12 bg-pink-600/20 rounded-full flex items-center justify-center flex-shrink-0 text-pink-500 font-bold text-xl">
                  4
                </div>
                <div>
                  <h4 className="text-lg font-bold text-white mb-2">Earn Rewards</h4>
                  <p className="text-slate-400">
                    Receive $50 bonus instantly credited to your account. Your friend gets $25 welcome bonus!
                  </p>
                </div>
              </div>
            </div>
          </Card>

          {/* Benefits */}
          <Card className="bg-slate-900 border-slate-700 p-8">
            <h3 className="text-xl font-bold text-white mb-6">Referral Benefits</h3>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="bg-slate-800/50 p-4 rounded-lg">
                <div className="flex items-center gap-3 mb-2">
                  <svg className="w-6 h-6 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-white font-semibold">Unlimited Referrals</span>
                </div>
                <p className="text-slate-400 text-sm">No limit on how many friends you can refer</p>
              </div>

              <div className="bg-slate-800/50 p-4 rounded-lg">
                <div className="flex items-center gap-3 mb-2">
                  <svg className="w-6 h-6 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-white font-semibold">Instant Rewards</span>
                </div>
                <p className="text-slate-400 text-sm">Bonuses credited immediately after conditions met</p>
              </div>

              <div className="bg-slate-800/50 p-4 rounded-lg">
                <div className="flex items-center gap-3 mb-2">
                  <svg className="w-6 h-6 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-white font-semibold">Lifetime Earnings</span>
                </div>
                <p className="text-slate-400 text-sm">Earn from every qualified referral forever</p>
              </div>

              <div className="bg-slate-800/50 p-4 rounded-lg">
                <div className="flex items-center gap-3 mb-2">
                  <svg className="w-6 h-6 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-white font-semibold">Easy Tracking</span>
                </div>
                <p className="text-slate-400 text-sm">Monitor your referrals and earnings in real-time</p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}
