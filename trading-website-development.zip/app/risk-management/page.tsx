"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Shield, TrendingDown, AlertTriangle, Target, Lock, DollarSign } from "lucide-react"
import { useRouter } from "next/navigation"

export default function RiskManagementPage() {
  const router = useRouter()

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <header className="bg-slate-900/80 backdrop-blur-sm border-b border-slate-700 p-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button onClick={() => router.push("/landing")} variant="ghost" className="text-slate-400 hover:text-white">
              ← Back
            </Button>
            <h1 className="text-2xl font-bold text-white flex items-center gap-2">
              <Shield className="h-6 w-6 text-blue-500" />
              Risk Management
            </h1>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto p-8">
        <Card className="bg-slate-900/80 backdrop-blur border-slate-700 mb-8">
          <CardHeader>
            <CardTitle className="text-3xl text-white">Understanding Risk Management in Trading</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6 text-slate-300">
            <p className="text-lg leading-relaxed">
              Risk management is the cornerstone of successful trading. It involves identifying, analyzing, and
              mitigating potential losses to protect your capital while maximizing profit opportunities. Without proper
              risk management, even the most profitable trading strategy can lead to catastrophic losses.
            </p>

            <div className="bg-blue-950/30 border border-blue-500/30 rounded-lg p-6">
              <h3 className="text-xl font-bold text-blue-400 mb-3">Why Risk Management Matters</h3>
              <p className="leading-relaxed">
                The financial markets are inherently unpredictable. Even experienced traders cannot predict every market
                movement with certainty. Risk management ensures that a series of losing trades doesn't wipe out your
                entire account, allowing you to stay in the game long enough to capitalize on winning trades.
                Professional traders often say: "Cut your losses short and let your winners run."
              </p>
            </div>
          </CardContent>
        </Card>

        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <Card className="bg-slate-900/80 backdrop-blur border-slate-700">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-white">
                <DollarSign className="h-5 w-5 text-emerald-500" />
                Position Sizing
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-slate-300">
              <p>
                Position sizing determines how much capital you allocate to each trade. The most common rule is the{" "}
                <strong>2% Rule</strong>: never risk more than 2% of your total trading capital on a single trade.
              </p>
              <p>
                For example, if you have $10,000 in your account, you should not risk more than $200 on any single
                trade. This ensures that even a series of 10 consecutive losses would only reduce your account by 20%,
                leaving you with $8,000 to continue trading.
              </p>
              <div className="bg-emerald-950/20 border border-emerald-500/30 rounded p-4">
                <p className="text-sm font-semibold text-emerald-400">Best Practice:</p>
                <p className="text-sm mt-2">
                  Calculate your position size based on your stop-loss distance and account size to maintain consistent
                  risk across all trades.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-900/80 backdrop-blur border-slate-700">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-white">
                <TrendingDown className="h-5 w-5 text-red-500" />
                Stop-Loss Orders
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-slate-300">
              <p>
                A stop-loss order automatically closes your position when the price reaches a predetermined level,
                limiting your potential loss. This is your safety net against unexpected market movements.
              </p>
              <p>
                Always set your stop-loss before entering a trade, not after. Emotional decision-making during a losing
                trade often leads to holding positions too long, hoping for a reversal that may never come.
              </p>
              <div className="bg-red-950/20 border border-red-500/30 rounded p-4">
                <p className="text-sm font-semibold text-red-400">Critical Rule:</p>
                <p className="text-sm mt-2">
                  Never move your stop-loss further away from entry to avoid being stopped out. This defeats its purpose
                  and increases your risk.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-900/80 backdrop-blur border-slate-700">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-white">
                <Target className="h-5 w-5 text-amber-500" />
                Risk-Reward Ratio
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-slate-300">
              <p>
                The risk-reward ratio compares potential profit to potential loss. A minimum 1:2 ratio is recommended,
                meaning you should aim to make at least $2 for every $1 you risk.
              </p>
              <p>
                For example, if you risk $100 (your stop-loss distance), your take-profit target should be at least
                $200. This allows you to be profitable even if you win only 40% of your trades.
              </p>
              <div className="bg-amber-950/20 border border-amber-500/30 rounded p-4">
                <p className="text-sm font-semibold text-amber-400">Key Insight:</p>
                <p className="text-sm mt-2">
                  A trader with a 1:3 risk-reward ratio needs to win only 25% of trades to break even, demonstrating the
                  power of good risk management.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-900/80 backdrop-blur border-slate-700">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-white">
                <AlertTriangle className="h-5 w-5 text-orange-500" />
                Diversification
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-slate-300">
              <p>
                Don't put all your eggs in one basket. Diversification involves spreading your capital across different
                assets, markets, or strategies to reduce overall portfolio risk.
              </p>
              <p>
                Trading multiple uncorrelated assets means that a loss in one position may be offset by gains in
                another. However, over-diversification can dilute profits and make portfolio management difficult.
              </p>
              <div className="bg-orange-950/20 border border-orange-500/30 rounded p-4">
                <p className="text-sm font-semibold text-orange-400">Optimal Approach:</p>
                <p className="text-sm mt-2">
                  Focus on 3-5 core assets you understand well rather than spreading yourself too thin across dozens of
                  markets.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="bg-slate-900/80 backdrop-blur border-slate-700 mb-8">
          <CardHeader>
            <CardTitle className="text-2xl text-white">Common Risk Management Mistakes</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-slate-300">
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <div className="bg-red-500 rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-white font-bold text-sm">1</span>
                </div>
                <div>
                  <p className="font-semibold text-white">Revenge Trading</p>
                  <p>
                    After a loss, traders often try to quickly recover by taking larger, riskier positions. This
                    emotional decision-making typically leads to even bigger losses.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-red-500 rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-white font-bold text-sm">2</span>
                </div>
                <div>
                  <p className="font-semibold text-white">Over-Leveraging</p>
                  <p>
                    Using excessive leverage amplifies both gains and losses. While it can multiply profits, it can also
                    wipe out your account with a single adverse move.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-red-500 rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-white font-bold text-sm">3</span>
                </div>
                <div>
                  <p className="font-semibold text-white">Ignoring Stop-Losses</p>
                  <p>
                    Moving or removing stop-losses during a trade because you "believe" the market will turn in your
                    favor is a recipe for disaster.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-red-500 rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-white font-bold text-sm">4</span>
                </div>
                <div>
                  <p className="font-semibold text-white">Lack of Trading Plan</p>
                  <p>
                    Trading without a defined strategy and risk parameters is gambling, not trading. Every trade should
                    have predetermined entry, exit, and stop-loss levels.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-red-500 rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-white font-bold text-sm">5</span>
                </div>
                <div>
                  <p className="font-semibold text-white">Overtrading</p>
                  <p>
                    Taking too many trades reduces the quality of your decision-making and increases transaction costs.
                    Focus on high-probability setups only.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900/80 backdrop-blur border-slate-700">
          <CardHeader>
            <CardTitle className="text-2xl text-white flex items-center gap-2">
              <Lock className="h-6 w-6 text-purple-500" />
              Psychological Aspects of Risk Management
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-slate-300">
            <p className="leading-relaxed">
              Risk management isn't just about numbers—it's deeply psychological. Fear and greed are the two primary
              emotions that cause traders to abandon their risk management rules. Fear can cause you to exit winning
              trades too early, while greed can make you hold losing positions too long or risk too much capital.
            </p>
            <p className="leading-relaxed">
              Successful traders develop emotional discipline through consistent application of their risk management
              rules, regardless of recent wins or losses. They understand that trading is a marathon, not a sprint, and
              that protecting capital is more important than chasing every potential profit.
            </p>
            <p className="leading-relaxed">
              Keep a trading journal to track not just your trades but also your emotional state during trading. This
              helps identify patterns where emotions override logic, allowing you to develop strategies to maintain
              discipline.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
