"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { fetchCryptoPrices, formatPrice, type CryptoPrice } from "@/lib/crypto-api"

export default function TradeListPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [prices, setPrices] = useState<CryptoPrice[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const currentUser = localStorage.getItem("currentUser")
    if (!currentUser) {
      router.push("/login")
      return
    }
    setUser(JSON.parse(currentUser))
  }, [router])

  useEffect(() => {
    loadPrices()
    const interval = setInterval(loadPrices, 5000) // Update every 5 seconds for real-time data
    return () => clearInterval(interval)
  }, [])

  const loadPrices = async () => {
    const data = await fetchCryptoPrices()
    setPrices(data)
    setLoading(false)
  }

  if (!user) {
    return null
  }

  const orderedPrices = [...prices.filter((p) => p.symbol === "GOLD"), ...prices.filter((p) => p.symbol !== "GOLD")]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="bg-slate-900/80 backdrop-blur-sm border-b border-slate-700 p-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              onClick={() => router.push("/dashboard")}
              variant="ghost"
              className="text-slate-400 hover:text-white"
            >
              ← Back
            </Button>
            <h1 className="text-2xl font-bold text-amber-500">Select Asset to Trade</h1>
          </div>
          <div className="text-right">
            <p className="text-sm text-slate-400">Balance</p>
            <p className="font-bold text-amber-500">${user.balance?.toLocaleString() || "10,000"}</p>
          </div>
        </div>
      </header>

      {/* Trade List */}
      <div className="max-w-7xl mx-auto p-8">
        {loading ? (
          <div className="text-center text-slate-400 py-12">Loading prices...</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {orderedPrices.map((crypto) => (
              <Card
                key={crypto.symbol}
                className="bg-slate-900/80 backdrop-blur border-slate-700 p-6 hover:bg-slate-800/80 transition-all cursor-pointer group"
                onClick={() => router.push(`/trading/${crypto.symbol}`)}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xl font-bold text-white">
                      {crypto.symbol === "GOLD" ? "COMEX Gold" : crypto.name}
                    </h3>
                    <p className="text-slate-400 text-sm">{crypto.symbol}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-white">{formatPrice(crypto.price)}</p>
                    <p
                      className={`text-sm font-semibold ${crypto.change24h >= 0 ? "text-emerald-500" : "text-red-500"}`}
                    >
                      {crypto.change24h >= 0 ? "+" : ""}
                      {crypto.change24h.toFixed(2)}%
                    </p>
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t border-slate-700">
                  <Button className="w-full bg-amber-600 hover:bg-amber-700 text-white font-semibold">Trade Now</Button>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
