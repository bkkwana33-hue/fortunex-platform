"use client"

import { useEffect, useState } from "react"
import { useRouter, useParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { fetchSingleCryptoPrice, formatPrice, type CryptoPrice } from "@/lib/crypto-api"

interface TradeTimeframe {
  duration: number
  label: string
  minAmount: number
  profitRange: string
}

const TIMEFRAMES: TradeTimeframe[] = [
  { duration: 60, label: "60s", minAmount: 500, profitRange: "5-10%" },
  { duration: 90, label: "90s", minAmount: 5000, profitRange: "12-15%" },
  { duration: 120, label: "120s", minAmount: 10000, profitRange: "15-20%" },
  { duration: 180, label: "180s", minAmount: 30000, profitRange: "20-25%" },
  { duration: 360, label: "360s", minAmount: 50000, profitRange: "25-30%" },
]

export default function TradingPage() {
  const router = useRouter()
  const params = useParams()
  const symbol = params.symbol as string

  const [user, setUser] = useState<any>(null)
  const [price, setPrice] = useState<CryptoPrice | null>(null)
  const [selectedTimeframe, setSelectedTimeframe] = useState<TradeTimeframe>(TIMEFRAMES[0])
  const [amount, setAmount] = useState("")
  const [error, setError] = useState("")

  useEffect(() => {
    const currentUser = localStorage.getItem("currentUser")
    if (!currentUser) {
      router.push("/login")
      return
    }
    setUser(JSON.parse(currentUser))
  }, [router])

  useEffect(() => {
    loadPrice()
    const interval = setInterval(loadPrice, 5000)
    return () => clearInterval(interval)
  }, [symbol])

  const loadPrice = async () => {
    const data = await fetchSingleCryptoPrice(symbol)
    setPrice(data)
  }

  const handleTrade = (type: "long" | "short") => {
    setError("")

    const tradeAmount = Number.parseFloat(amount)

    if (!tradeAmount || tradeAmount < selectedTimeframe.minAmount) {
      setError(`Minimum amount for ${selectedTimeframe.label} is $${selectedTimeframe.minAmount.toLocaleString()}`)
      return
    }

    if (tradeAmount > user.balance) {
      setError("Insufficient balance")
      return
    }

    const trade = {
      id: Date.now(),
      symbol,
      name: price?.name || symbol,
      type,
      amount: tradeAmount,
      entryPrice: price?.price || 0,
      timeframe: selectedTimeframe.duration,
      timeframeLabel: selectedTimeframe.label,
      profitRange: selectedTimeframe.profitRange,
      startTime: Date.now(),
      status: "active",
    }

    // Get existing trades
    const tradesData = localStorage.getItem("activeTrades") || "[]"
    const trades = JSON.parse(tradesData)
    trades.push(trade)
    localStorage.setItem("activeTrades", JSON.stringify(trades))

    // Update user balance
    const updatedUser = { ...user, balance: user.balance - tradeAmount }
    localStorage.setItem("currentUser", JSON.stringify(updatedUser))

    // Update users array
    const usersData = localStorage.getItem("users") || "[]"
    const users = JSON.parse(usersData)
    const userIndex = users.findIndex((u: any) => u.email === user.email)
    if (userIndex !== -1) {
      users[userIndex] = updatedUser
      localStorage.setItem("users", JSON.stringify(users))
    }

    router.push("/active-trades")
  }

  if (!user || !price) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-slate-400">Loading...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="bg-slate-900/80 backdrop-blur-sm border-b border-slate-700 p-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              onClick={() => router.push("/trade-list")}
              variant="ghost"
              className="text-slate-400 hover:text-white"
            >
              ← Back
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-white">{price.name}</h1>
              <p className="text-slate-400">{price.symbol}</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-sm text-slate-400">Balance</p>
            <p className="font-bold text-amber-500">${user.balance?.toLocaleString()}</p>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto p-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Price Display */}
          <Card className="lg:col-span-1 bg-slate-900/80 backdrop-blur border-slate-700 p-6">
            <div className="text-center space-y-4">
              <h3 className="text-slate-400">Current Price</h3>
              <p className="text-4xl font-bold text-white">{formatPrice(price.price)}</p>
              <p className={`text-xl font-semibold ${price.change24h >= 0 ? "text-emerald-500" : "text-red-500"}`}>
                {price.change24h >= 0 ? "+" : ""}
                {price.change24h.toFixed(2)}% (24h)
              </p>
            </div>
          </Card>

          {/* Trading Interface */}
          <Card className="lg:col-span-2 bg-slate-900/80 backdrop-blur border-slate-700 p-6">
            <h2 className="text-2xl font-bold text-white mb-6">Place Trade</h2>

            {/* Timeframe Selection */}
            <div className="mb-6">
              <label className="text-slate-400 text-sm mb-3 block">Select Timeframe</label>
              <div className="grid grid-cols-5 gap-2">
                {TIMEFRAMES.map((tf) => (
                  <button
                    key={tf.duration}
                    onClick={() => setSelectedTimeframe(tf)}
                    className={`p-3 rounded-lg border-2 transition-all ${
                      selectedTimeframe.duration === tf.duration
                        ? "border-amber-500 bg-amber-500/20"
                        : "border-slate-700 hover:border-slate-600"
                    }`}
                  >
                    <div className="text-white font-bold">{tf.label}</div>
                    <div className="text-xs text-slate-400">{tf.profitRange}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Amount Input */}
            <div className="mb-6">
              <label className="text-slate-400 text-sm mb-2 block">
                Trade Amount (Min: ${selectedTimeframe.minAmount.toLocaleString()})
              </label>
              <Input
                type="number"
                placeholder="Enter amount"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="bg-slate-800 border-slate-700 text-white text-xl p-6"
              />
            </div>

            {error && <div className="mb-4 text-red-400 text-sm bg-red-950/20 p-3 rounded">{error}</div>}

            {/* Trade Buttons */}
            <div className="grid grid-cols-2 gap-4 mb-6">
              <Button
                onClick={() => handleTrade("long")}
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-6 text-lg"
              >
                Buy Long ↑
              </Button>
              <Button
                onClick={() => handleTrade("short")}
                className="bg-red-600 hover:bg-red-700 text-white font-bold py-6 text-lg"
              >
                Sell Short ↓
              </Button>
            </div>

            {/* Mega Trade Button */}
            <Button
              onClick={() => router.push(`/mega-trade/${symbol}`)}
              className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-bold py-6 text-xl"
            >
              MEGA TRADE 🚀
            </Button>
          </Card>
        </div>
      </div>
    </div>
  )
}
