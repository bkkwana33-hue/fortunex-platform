"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { TrendingUp, Mail, CheckCircle } from "lucide-react"
import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"

export default function VerifyEmailPage() {
  const router = useRouter()
  const [verificationCode, setVerificationCode] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const [email, setEmail] = useState("")
  const [actualCode, setActualCode] = useState("")
  const [resendLoading, setResendLoading] = useState(false)
  const [resendSuccess, setResendSuccess] = useState(false)

  useEffect(() => {
    // Get temporary signup data
    const tempSignup = localStorage.getItem("tempSignup")
    if (!tempSignup) {
      router.push("/signup")
      return
    }

    const data = JSON.parse(tempSignup)
    setEmail(data.email)
    setActualCode(data.verificationCode)

    // Display the code in console (simulating email)
    console.log("=".repeat(50))
    console.log("📧 EMAIL VERIFICATION CODE")
    console.log("=".repeat(50))
    console.log(`To: ${data.email}`)
    console.log(`Your verification code is: ${data.verificationCode}`)
    console.log("=".repeat(50))
  }, [router])

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (!verificationCode) {
      setError("Please enter the verification code")
      return
    }

    if (verificationCode.length !== 6) {
      setError("Verification code must be 6 digits")
      return
    }

    setLoading(true)

    setTimeout(() => {
      const tempSignup = localStorage.getItem("tempSignup")
      if (!tempSignup) {
        setError("Session expired. Please sign up again.")
        setLoading(false)
        return
      }

      const data = JSON.parse(tempSignup)

      if (verificationCode === data.verificationCode) {
        const users = JSON.parse(localStorage.getItem("users") || "[]")
        const newUser = {
          id: data.userId.toString(),
          userId: data.userId,
          fullName: data.fullName,
          username: data.email.split("@")[0],
          email: data.email,
          phone: data.phone,
          password: data.password,
          balance: 0, // Start with $0 balance
          verified: true,
          allowed: false, // Must be allowed by admin for profitable trades
          createdAt: new Date().toISOString(),
        }
        users.push(newUser)
        localStorage.setItem("users", JSON.stringify(users))
        localStorage.setItem("currentUser", JSON.stringify(newUser))
        localStorage.removeItem("tempSignup")

        setLoading(false)
        router.push("/login")
      } else {
        setError("Invalid verification code. Please try again.")
        setLoading(false)
      }
    }, 1000)
  }

  const handleResendCode = () => {
    setResendLoading(true)
    setResendSuccess(false)

    setTimeout(() => {
      const tempSignup = localStorage.getItem("tempSignup")
      if (tempSignup) {
        const data = JSON.parse(tempSignup)
        const newCode = Math.floor(100000 + Math.random() * 900000).toString()
        data.verificationCode = newCode
        data.timestamp = Date.now()
        localStorage.setItem("tempSignup", JSON.stringify(data))
        setActualCode(newCode)

        // Display new code in console
        console.log("=".repeat(50))
        console.log("📧 NEW EMAIL VERIFICATION CODE")
        console.log("=".repeat(50))
        console.log(`To: ${data.email}`)
        console.log(`Your new verification code is: ${newCode}`)
        console.log("=".repeat(50))

        setResendSuccess(true)
      }
      setResendLoading(false)
    }, 1000)
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="flex items-center justify-center gap-2 mb-8">
          <TrendingUp className="h-8 w-8 text-primary" />
          <span className="text-2xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
            CryptoTrade
          </span>
        </div>

        <Card>
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <div className="rounded-full bg-primary/10 p-3">
                <Mail className="h-8 w-8 text-primary" />
              </div>
            </div>
            <CardTitle className="text-2xl">Verify Your Email</CardTitle>
            <CardDescription>
              We've sent a verification code to <br />
              <span className="font-semibold text-foreground">{email}</span>
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleVerify} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="code">Verification Code</Label>
                <Input
                  id="code"
                  type="text"
                  placeholder="Enter 6-digit code"
                  value={verificationCode}
                  onChange={(e) => {
                    const value = e.target.value.replace(/\D/g, "").slice(0, 6)
                    setVerificationCode(value)
                    setError("")
                  }}
                  className={`text-center text-2xl tracking-widest ${error ? "border-red-500" : ""}`}
                  maxLength={6}
                />
                {error && <p className="text-sm text-red-500 text-center">{error}</p>}
              </div>

              <div className="bg-muted/50 p-3 rounded-lg text-sm text-muted-foreground text-center">
                Check your email inbox and spam folder for the verification code
              </div>

              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? "Verifying..." : "Verify Email"}
              </Button>

              <div className="text-center space-y-2">
                <p className="text-sm text-muted-foreground">Didn't receive the code?</p>
                <Button
                  type="button"
                  variant="ghost"
                  onClick={handleResendCode}
                  disabled={resendLoading}
                  className="text-primary"
                >
                  {resendLoading ? "Sending..." : "Resend Code"}
                </Button>
                {resendSuccess && (
                  <p className="text-sm text-green-600 flex items-center justify-center gap-1">
                    <CheckCircle className="h-4 w-4" />
                    New code sent successfully!
                  </p>
                )}
              </div>
            </form>

            <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-950/30 rounded-lg border border-blue-200 dark:border-blue-900">
              <p className="text-sm text-blue-800 dark:text-blue-200 text-center">
                <strong>Demo Mode:</strong> Check the browser console (F12) to see your verification code
              </p>
            </div>
          </CardContent>
        </Card>

        <div className="mt-6 text-center">
          <Link href="/signup" className="text-sm text-muted-foreground hover:text-primary">
            Back to Sign Up
          </Link>
        </div>
      </div>
    </div>
  )
}
