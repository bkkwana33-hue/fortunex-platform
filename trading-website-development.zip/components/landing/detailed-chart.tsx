"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface CandleData {
  time: number
  open: number
  high: number
  low: number
  close: number
  volume: number
}

interface DetailedChartProps {
  symbol: string
  name: string
  currentPrice: number
}

export function DetailedChart({ symbol, name, currentPrice }: DetailedChartProps) {
  const [candles, setCandles] = useState<CandleData[]>([])

  useEffect(() => {
    const now = Date.now()
    const initialCandles: CandleData[] = []
    let price = currentPrice * 0.95

    for (let i = 50; i >= 0; i--) {
      const variation = (Math.random() - 0.5) * price * 0.02
      const open = price
      const close = price + variation
      const high = Math.max(open, close) + Math.abs(variation) * 0.5
      const low = Math.min(open, close) - Math.abs(variation) * 0.5
      const volume = Math.random() * 1000000

      initialCandles.push({
        time: now - i * 5000,
        open,
        high,
        low,
        close,
        volume,
      })
      price = close
    }

    setCandles(initialCandles)

    const interval = setInterval(() => {
      setCandles((prev) => {
        const lastCandle = prev[prev.length - 1]
        const variation = (Math.random() - 0.5) * lastCandle.close * 0.01
        const newCandle: CandleData = {
          time: Date.now(),
          open: lastCandle.close,
          close: lastCandle.close + variation,
          high: Math.max(lastCandle.close, lastCandle.close + variation) + Math.abs(variation) * 0.3,
          low: Math.min(lastCandle.close, lastCandle.close + variation) - Math.abs(variation) * 0.3,
          volume: Math.random() * 1000000,
        }

        return [...prev.slice(-50), newCandle]
      })
    }, 5000)

    return () => clearInterval(interval)
  }, [currentPrice])

  if (candles.length === 0) {
    return (
      <Card>
        <CardContent className="h-96 flex items-center justify-center">
          <div className="text-muted-foreground">Loading chart...</div>
        </CardContent>
      </Card>
    )
  }

  const maxPrice = Math.max(...candles.map((c) => c.high))
  const minPrice = Math.min(...candles.map((c) => c.low))
  const priceRange = maxPrice - minPrice
  const maxVolume = Math.max(...candles.map((c) => c.volume))

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>
            {name} ({symbol})
          </span>
          <span className="text-2xl font-bold">${currentPrice.toFixed(2)}</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Price Chart */}
          <div className="relative h-80 bg-card border rounded-lg p-4">
            <svg width="100%" height="100%" className="overflow-visible">
              {candles.map((candle, index) => {
                const x = (index / candles.length) * 100
                const width = (100 / candles.length) * 0.6

                const highY = ((maxPrice - candle.high) / priceRange) * 90 + 5
                const lowY = ((maxPrice - candle.low) / priceRange) * 90 + 5
                const openY = ((maxPrice - candle.open) / priceRange) * 90 + 5
                const closeY = ((maxPrice - candle.close) / priceRange) * 90 + 5

                const isGreen = candle.close >= candle.open
                const color = isGreen ? "rgb(34 197 94)" : "rgb(239 68 68)"

                return (
                  <g key={candle.time}>
                    <line
                      x1={`${x + width / 2}%`}
                      y1={`${highY}%`}
                      x2={`${x + width / 2}%`}
                      y2={`${lowY}%`}
                      stroke={color}
                      strokeWidth="1"
                    />
                    <rect
                      x={`${x}%`}
                      y={`${Math.min(openY, closeY)}%`}
                      width={`${width}%`}
                      height={`${Math.abs(closeY - openY) || 0.5}%`}
                      fill={color}
                    />
                  </g>
                )
              })}
            </svg>

            {/* Price Labels */}
            <div className="absolute left-0 top-4 text-xs text-muted-foreground">${maxPrice.toFixed(2)}</div>
            <div className="absolute left-0 bottom-4 text-xs text-muted-foreground">${minPrice.toFixed(2)}</div>
          </div>

          {/* Volume Chart */}
          <div className="relative h-24 bg-card border rounded-lg p-4">
            <svg width="100%" height="100%">
              {candles.map((candle, index) => {
                const x = (index / candles.length) * 100
                const width = (100 / candles.length) * 0.6
                const height = (candle.volume / maxVolume) * 80

                const isGreen = candle.close >= candle.open
                const color = isGreen ? "rgba(34, 197, 94, 0.5)" : "rgba(239, 68, 68, 0.5)"

                return (
                  <rect
                    key={candle.time}
                    x={`${x}%`}
                    y={`${100 - height}%`}
                    width={`${width}%`}
                    height={`${height}%`}
                    fill={color}
                  />
                )
              })}
            </svg>
            <div className="absolute left-0 top-0 text-xs text-muted-foreground">Volume</div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
