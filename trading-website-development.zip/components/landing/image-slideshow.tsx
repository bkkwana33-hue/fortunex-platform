"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"

const images = [
  {
    src: "/images/market-news.jpg",
    alt: "Market News - Gold vs Stocks and Bitcoin",
  },
  {
    src: "/images/bitcoin-crypto.webp",
    alt: "Bitcoin Crypto vs Gold",
  },
  {
    src: "/images/gold-bitcoin.jpg",
    alt: "Gold and Bitcoin Trading",
  },
]

const welcomeMessages = [
  "Infinity - Your Gateway to the Trading World",
  "Welcome to the World of Finance",
  "Trade with Confidence - Trade with Infinity",
]

export function ImageSlideshow() {
  const [currentIndex, setCurrentIndex] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % images.length)
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  const goToPrevious = () => {
    setCurrentIndex((prev) => (prev - 1 + images.length) % images.length)
  }

  const goToNext = () => {
    setCurrentIndex((prev) => (prev + 1) % images.length)
  }

  return (
    <div className="relative w-full max-w-5xl mx-auto rounded-xl overflow-hidden border bg-card shadow-lg">
      {/* Slideshow Images */}
      <div className="relative aspect-video w-full">
        {images.map((image, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-700 ${
              index === currentIndex ? "opacity-100" : "opacity-0"
            }`}
          >
            <Image
              src={image.src || "/placeholder.svg"}
              alt={image.alt}
              fill
              className="object-cover"
              priority={index === 0}
            />
          </div>
        ))}

        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-black/30" />

        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center px-8">
            {welcomeMessages.map((message, index) => (
              <h1
                key={index}
                className={`text-4xl md:text-5xl lg:text-6xl font-bold text-white drop-shadow-2xl transition-opacity duration-700 ${
                  index === currentIndex ? "opacity-100" : "opacity-0 absolute inset-0 flex items-center justify-center"
                }`}
              >
                {message}
              </h1>
            ))}
          </div>
        </div>
      </div>

      {/* Navigation Buttons */}
      <Button
        variant="ghost"
        size="icon"
        className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/30 hover:bg-black/50 text-white"
        onClick={goToPrevious}
      >
        <ChevronLeft className="h-6 w-6" />
      </Button>

      <Button
        variant="ghost"
        size="icon"
        className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/30 hover:bg-black/50 text-white"
        onClick={goToNext}
      >
        <ChevronRight className="h-6 w-6" />
      </Button>

      {/* Dots Indicator */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
        {images.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentIndex(index)}
            className={`w-2 h-2 rounded-full transition-all ${
              index === currentIndex ? "bg-white w-8" : "bg-white/50 hover:bg-white/75"
            }`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </div>
  )
}
