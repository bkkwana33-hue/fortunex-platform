"use client"

import { useEffect, useState } from "react"

interface CandleData {
  time: number
  open: number
  high: number
  low: number
  close: number
}

interface MarketMiniChartProps {
  symbol: string
  currentPrice: number
}

export function MarketMiniChart({ symbol, currentPrice }: MarketMiniChartProps) {
  const [candles, setCandles] = useState<CandleData[]>([])

  useEffect(() => {
    // Initialize with historical data
    const now = Date.now()
    const initialCandles: CandleData[] = []
    let price = currentPrice * 0.98

    for (let i = 20; i >= 0; i--) {
      const variation = (Math.random() - 0.5) * price * 0.02
      const open = price
      const close = price + variation
      const high = Math.max(open, close) + Math.abs(variation) * 0.5
      const low = Math.min(open, close) - Math.abs(variation) * 0.5

      initialCandles.push({
        time: now - i * 5000,
        open,
        high,
        low,
        close,
      })
      price = close
    }

    setCandles(initialCandles)

    // Update with new candles
    const interval = setInterval(() => {
      setCandles((prev) => {
        const lastCandle = prev[prev.length - 1]
        const variation = (Math.random() - 0.5) * lastCandle.close * 0.01
        const newCandle: CandleData = {
          time: Date.now(),
          open: lastCandle.close,
          close: lastCandle.close + variation,
          high: Math.max(lastCandle.close, lastCandle.close + variation) + Math.abs(variation) * 0.3,
          low: Math.min(lastCandle.close, lastCandle.close + variation) - Math.abs(variation) * 0.3,
        }

        const updated = [...prev.slice(-20), newCandle]
        return updated
      })
    }, 5000)

    return () => clearInterval(interval)
  }, [currentPrice])

  if (candles.length === 0) {
    return <div className="h-16 bg-muted/20 animate-pulse rounded" />
  }

  const maxPrice = Math.max(...candles.map((c) => c.high))
  const minPrice = Math.min(...candles.map((c) => c.low))
  const priceRange = maxPrice - minPrice

  return (
    <div className="relative h-16 w-full">
      <svg width="100%" height="100%" className="overflow-visible">
        {candles.map((candle, index) => {
          const x = (index / candles.length) * 100
          const width = (100 / candles.length) * 0.8

          const highY = ((maxPrice - candle.high) / priceRange) * 100
          const lowY = ((maxPrice - candle.low) / priceRange) * 100
          const openY = ((maxPrice - candle.open) / priceRange) * 100
          const closeY = ((maxPrice - candle.close) / priceRange) * 100

          const isGreen = candle.close >= candle.open
          const color = isGreen ? "rgb(34 197 94)" : "rgb(239 68 68)"

          return (
            <g key={candle.time}>
              <line
                x1={`${x + width / 2}%`}
                y1={`${highY}%`}
                x2={`${x + width / 2}%`}
                y2={`${lowY}%`}
                stroke={color}
                strokeWidth="1"
              />
              <rect
                x={`${x}%`}
                y={`${Math.min(openY, closeY)}%`}
                width={`${width}%`}
                height={`${Math.abs(closeY - openY) || 1}%`}
                fill={color}
              />
            </g>
          )
        })}
      </svg>
    </div>
  )
}
