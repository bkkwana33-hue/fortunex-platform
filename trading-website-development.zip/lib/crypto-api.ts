"use client"

export interface CryptoPrice {
  symbol: string
  name: string
  price: number
  change24h: number
  high24h: number
  low24h: number
  volume24h: number
  marketCap: number
}

// Supported cryptocurrencies including gold
export const SUPPORTED_CRYPTOS = [
  { symbol: "BTC", name: "Bitcoin", coingeckoId: "bitcoin" },
  { symbol: "ETH", name: "Ethereum", coingeckoId: "ethereum" },
  { symbol: "BNB", name: "Binance Coin", coingeckoId: "binancecoin" },
  { symbol: "XRP", name: "Ripple", coingeckoId: "ripple" },
  { symbol: "SOL", name: "Solana", coingeckoId: "solana" },
  { symbol: "DOGE", name: "Dogecoin", coingeckoId: "dogecoin" },
  { symbol: "ADA", name: "Cardano", coingeckoId: "cardano" },
  { symbol: "GOLD", name: "Gold", coingeckoId: "pax-gold" },
]

const priceCache: Map<string, { data: CryptoPrice; timestamp: number }> = new Map()
const CACHE_DURATION = 10000 // 10 seconds

export async function fetchCryptoPrices(): Promise<CryptoPrice[]> {
  try {
    const response = await fetch("/api/crypto-prices")

    if (!response.ok) {
      throw new Error("Failed to fetch prices")
    }

    const data = await response.json()

    return SUPPORTED_CRYPTOS.map((crypto) => {
      const coinData = data.find((d: any) => d.id === crypto.coingeckoId)

      if (coinData) {
        return {
          symbol: crypto.symbol,
          name: crypto.name,
          price: coinData.current_price,
          change24h: coinData.price_change_percentage_24h || 0,
          high24h: coinData.high_24h || coinData.current_price,
          low24h: coinData.low_24h || coinData.current_price,
          volume24h: coinData.total_volume || 0,
          marketCap: coinData.market_cap || 0,
        }
      }

      return {
        symbol: crypto.symbol,
        name: crypto.name,
        price: 0,
        change24h: 0,
        high24h: 0,
        low24h: 0,
        volume24h: 0,
        marketCap: 0,
      }
    })
  } catch (error) {
    console.error("Error fetching crypto prices:", error)
    // Return empty array instead of zeros
    return []
  }
}

export async function fetchSingleCryptoPrice(symbol: string): Promise<CryptoPrice | null> {
  const now = Date.now()
  const cached = priceCache.get(symbol)

  if (cached && now - cached.timestamp < CACHE_DURATION) {
    return cached.data
  }

  try {
    const allPrices = await fetchCryptoPrices()
    const priceData = allPrices.find((p) => p.symbol === symbol)

    if (priceData) {
      priceCache.set(symbol, { data: priceData, timestamp: now })
      return priceData
    }

    return null
  } catch (error) {
    console.error("Error fetching crypto price:", error)
    return null
  }
}

export function formatPrice(price: number): string {
  if (price >= 1000) {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(price)
  }
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
    maximumFractionDigits: 6,
  }).format(price)
}

export function formatLargeNumber(num: number): string {
  if (num >= 1e12) {
    return `$${(num / 1e12).toFixed(2)}T`
  }
  if (num >= 1e9) {
    return `$${(num / 1e9).toFixed(2)}B`
  }
  if (num >= 1e6) {
    return `$${(num / 1e6).toFixed(2)}M`
  }
  if (num >= 1e3) {
    return `$${(num / 1e3).toFixed(2)}K`
  }
  return `$${num.toFixed(2)}`
}
